// ============================================================================
// DBEAutoPilot.js — PixInsight PJSR 腳本
// 從「剛疊好、還沒做過 DBE」的圖開始，一次做完整套流程：
//
//   1) 在你選的圖上，用一組自動產生的網格 sample point 跑一次「初始 DBE」
//      （複製品上執行，不動原圖），取得背景模型與殘差資料
//   2) 匯出診斷資料，透過 ExternalProcess 自動呼叫既有的
//      bridge/dbe_advisor.py（預設 claude-opus-4-6 + effort=medium）分析
//   3) 依 AI 回傳的 sample_point_actions / parameter_suggestions 組出新的
//      sample table 與參數
//   4) 用新參數在「原圖的另一份複製品」上執行最終 DBE —— 全自動執行，
//      不再跳出確認對話框
//
// 安全性設計（務必先讀）：
//   - 全程「絕不」直接修改或覆蓋你選定的原始影像視窗；每次執行 DBE 都是
//     先複製一份新視窗才動手。最終結果會是兩個新視窗：
//       <來源ID>_DBE_AI        — 背景校正後的影像
//       <來源ID>_background_AI — 對應的背景模型
//     你原本選的視窗全程不受影響，最終看不順眼可以直接關掉這兩個新視窗重來。
//   - 本腳本會在你電腦上啟動一個外部 Python 行程（呼叫 Claude API），
//     需要：
//       a) 已安裝 anthropic 套件（pip install anthropic）
//       b) ANTHROPIC_API_KEY 已設定為「系統/使用者環境變數」
//          （不是只在某個終端機視窗用 export 設的暫時變數——PixInsight
//          啟動的行程不會繼承那種暫時變數，必須是永久環境變數）
//   - DynamicBackgroundExtraction 的屬性名稱（tolerance / shadowsRelaxation /
//     smoothing / sampleSize / samplesPerRow / minWeight 等）沿用
//     DBEDiagExporter.js / DBEAutoApply.js 已經反推驗證過的欄位；若你的
//     PixInsight 版本欄位不同，請對照 Process Console 印出的內容調整
//     setByExistingName() 呼叫處的候選名稱陣列。
//   - 「自動偵測背景模型視窗」是用「執行前後視窗列表的差異」來抓，而不是
//     猜測固定命名規則，理論上比較不受版本差異影響；但如果你的 DBE 版本
//     預設會丟掉背景模型視窗（不產生），這裡會直接中止並提示你，不會
//     悶不吭聲地用假資料繼續。
//   - 因為選擇了「全自動執行、不再跳出確認對話框」，建議第一次使用時，
//     先在不重要的測試疊圖上跑過、確認符合預期，再套用在正式成品上。
// ============================================================================

#feature-id   DBEAutoPilot
#feature-info 從原始疊圖到 AI 分析、全自動套用 DBE 的一站式流程

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ImageOp.jsh>

#include "DBEAdvisorEngine.jsh"

#define VERSION "2.3.0"
#define TITLE   "DBE Auto Pilot"

// Settings 鍵前綴（API Key、輸出目錄、偏好設定的持久化）
#define SETTINGS_PREFIX "DBEAutoPilot/"

function loadSetting(key, dflt) {
   var v = Settings.read(SETTINGS_PREFIX + key, DataType_UCString);
   return (Settings.lastReadOK && v) ? v : dflt;
}

function saveSetting(key, value) {
   Settings.write(SETTINGS_PREFIX + key, DataType_UCString, String(value));
}

/**
 * 預設輸出目錄：使用者家目錄下的 DBEAutoPilot（可攜式，
 * 不寫死任何機器特定路徑；使用者改過的路徑會存在 Settings）
 */
function defaultOutputDir() {
   return File.homeDirectory + "/DBEAutoPilot";
}

// 離線 fallback 模型清單（連得上網時會改用 /v1/models 的即時清單）
var DEFAULT_MODELS = [
   "claude-opus-4-6",
   "claude-opus-4-8",
   "claude-sonnet-4-6",
   "claude-sonnet-5",
   "claude-haiku-4-5"
];

/**
 * 取得模型清單：優先用 Settings 快取；無快取且有 API Key 時
 * 連網查 /v1/models（成功後寫入快取）；離線/失敗 fallback 到 DEFAULT_MODELS。
 * @param {Boolean} forceRefresh  true = 忽略快取強制重查
 */
function getModelList(apiKey, forceRefresh) {
   if (!forceRefresh) {
      var cached = loadSetting("modelList", "");
      if (cached) return cached.split(",");
   }
   if (apiKey) {
      try {
         var ids = fetchAvailableModels(apiKey);
         saveSetting("modelList", ids.join(","));
         console.writeln("已從 Anthropic API 取得 " + ids.length + " 個可用模型。");
         return ids;
      } catch (e) {
         console.warningln("無法取得線上模型清單（" + e + "），使用預設清單。");
      }
   }
   return DEFAULT_MODELS;
}

var REGION_RE = /\(\s*(-?\d+)\s*px\s*,\s*(-?\d+)\s*px\s*\)\s*~\s*\(\s*(-?\d+)\s*px\s*,\s*(-?\d+)\s*px\s*\)/;

// AI 報告的參數名稱 → DBE 對話框介面上的實際位置（PixInsight 1.9.x）
var PARAM_UI_MAP = {
   tolerance:         "Model Parameters (1) → Tolerance",
   shadowsRelaxation: "Model Parameters (1) → Shadows relaxation",
   smoothingFactor:   "Model Parameters (1) → Smoothing factor",
   sampleRadius:      "Sample Generation → Default sample radius",
   samplesPerRow:     "Sample Generation → Samples per row",
   minSampleWeight:   "Sample Generation → Minimum sample weight"
};

// ─────────────────────────────────────────────
// 小工具
// ─────────────────────────────────────────────

function timestampString() {
   var d = new Date();
   function p2(n) { return (n < 10 ? "0" : "") + n; }
   return d.getFullYear().toString() +
          p2(d.getMonth() + 1) + p2(d.getDate()) + "_" +
          p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds());
}

function readTextFile(path) {
   var f = new File;
   f.openForReading(path);
   var buffer = f.read(DataType_ByteArray, f.size);
   f.close();
   // AI 報告 JSON 是 UTF-8 且含繁體中文；toString() 不是 UTF-8 解碼，
   // 會把中文變成亂碼（實測），必須用 utf8ToString()。
   return (typeof buffer.utf8ToString === "function") ? buffer.utf8ToString()
                                                      : buffer.toString();
}

function writeTextFile(path, text) {
   var f = new File;
   f.createForWriting(path);
   // 以 UTF-8 寫出。注意：new ByteArray(String) 只會取每個 UTF-16 code unit
   // 的低位元組（實測中文全毀），並不會做 UTF-8 編碼。
   // 因此先用 encodeURIComponent + unescape 把字串轉成「每個字元都 <= 0xFF
   // 的 UTF-8 位元組序列」，再交給 ByteArray 取低位元組，結果即為正確的 UTF-8。
   var utf8 = unescape(encodeURIComponent(text));
   f.write(new ByteArray(utf8));
   f.close();
}

function parseRegion(str) {
   if (!str) return null;
   var m = REGION_RE.exec(str);
   if (!m) return null;
   var x0 = parseInt(m[1], 10), y0 = parseInt(m[2], 10);
   var x1 = parseInt(m[3], 10), y1 = parseInt(m[4], 10);
   return {
      x0: Math.min(x0, x1), y0: Math.min(y0, y1),
      x1: Math.max(x0, x1), y1: Math.max(y0, y1)
   };
}

function guessCount(text, dflt) {
   if (!text) return dflt;
   var re = /(\d+)\s*[-~至到]\s*(\d+)\s*個|(\d+)\s*個/g;
   var m, last = null;
   while ((m = re.exec(text)) !== null) last = m;
   if (!last) return dflt;
   var n;
   if (last[3] !== undefined) {
      n = parseInt(last[3], 10);
   } else {
      n = Math.round((parseInt(last[1], 10) + parseInt(last[2], 10)) / 2);
   }
   return Math.max(1, Math.min(6, n));
}

function spreadPoints(box, n) {
   var pts = [];
   var cols = Math.ceil(Math.sqrt(n));
   var rows = Math.ceil(n / cols);
   var w = box.x1 - box.x0, h = box.y1 - box.y0;
   var idx = 0;
   for (var r = 0; r < rows && idx < n; r++) {
      for (var c = 0; c < cols && idx < n; c++) {
         var fx = (c + 1) / (cols + 1);
         var fy = (r + 1) / (rows + 1);
         pts.push({ x: box.x0 + fx * w, y: box.y0 + fy * h });
         idx++;
      }
   }
   return pts;
}

function setByExistingName(P, names, value) {
   for (var i = 0; i < names.length; i++) {
      if (typeof P[names[i]] === "number") {
         P[names[i]] = value;
         return names[i];
      }
   }
   return null;
}

/**
 * 複製一個 view 成新視窗，原視窗完全不受影響。
 */
function cloneViewToNewWindow(view, newId) {
   var img = view.image;
   var w = new ImageWindow(
      img.width, img.height, img.numberOfChannels,
      view.window.bitsPerSample, view.window.isFloatSample,
      img.colorSpace !== ColorSpace_Gray, newId
   );
   w.mainView.beginProcess(0); // UndoFlag_NoUndo（此環境下具名常數未解析，改用數值 0）
   w.mainView.image.assign(img);
   w.mainView.endProcess();
   return w;
}

// ─────────────────────────────────────────────
// 影像統計 / 殘差網格 / DBE 參數擷取
// （沿用 DBEDiagExporter.js 已驗證過的邏輯）
// ─────────────────────────────────────────────

function channelStats(img, channel) {
   img.selectedChannel = channel;
   return {
      mean: img.mean(), median: img.median(), stdDev: img.stdDev(),
      min: img.minimum(), max: img.maximum(), MAD: img.MAD()
   };
}

function computeResidualGrid(srcImg, bgImg, gridN) {
   if (!gridN) gridN = 8;
   var w = srcImg.width, h = srcImg.height;
   var cellW = Math.floor(w / gridN), cellH = Math.floor(h / gridN);
   var grid = [];

   var residual = new Image(w, h, srcImg.numberOfChannels,
                             srcImg.colorSpace, 32, SampleType_Real);
   residual.assign(srcImg);
   residual.apply(bgImg, ImageOp_Sub);

   var numCh = 0;
   var maxPossibleCh = residual.numberOfChannels;
   for (var probeCh = 0; probeCh < maxPossibleCh; probeCh++) {
      try { residual.selectedChannel = probeCh; numCh++; }
      catch (e) { break; }
   }
   if (numCh === 0) numCh = 1;

   for (var row = 0; row < gridN; row++) {
      var rowArr = [];
      for (var col = 0; col < gridN; col++) {
         var x0 = col * cellW, y0 = row * cellH;
         var x1 = (col === gridN - 1) ? w : x0 + cellW;
         var y1 = (row === gridN - 1) ? h : y0 + cellH;
         residual.selectedRect = new Rect(x0, y0, x1, y1);

         var meanByChannel = [], stdDevByChannel = [];
         for (var ch = 0; ch < numCh; ch++) {
            residual.selectedChannel = ch;
            meanByChannel.push(residual.mean());
            stdDevByChannel.push(residual.stdDev());
         }
         var cellMean = meanByChannel.reduce(function(a, b) { return a + b; }, 0) / numCh;
         var cellStdDev = stdDevByChannel.reduce(function(a, b) { return a + b; }, 0) / numCh;

         rowArr.push({
            row: row, col: col, x0: x0, y0: y0, x1: x1, y1: y1,
            meanByChannel: meanByChannel, stdDevByChannel: stdDevByChannel,
            mean: cellMean, stdDev: cellStdDev
         });
      }
      grid.push(rowArr);
   }
   residual.free();
   return grid;
}

function extractDBEParams(P, imgW, imgH, numChannels) {
   function num(name, dflt) {
      return (typeof P[name] === "number") ? P[name] : dflt;
   }
   var params = {
      tolerance:         num("tolerance", 0),
      shadowsRelaxation: num("shadowsRelaxation", 0),
      smoothingFactor:   num("smoothing", num("smoothFactor", 0)),
      sampleRadius:      num("sampleSize", num("defaultSampleRadius", 0)),
      samplesPerRow:     num("samplesPerRow", 0),
      minSampleWeight:   num("minWeight", num("minSampleWeight", 0)),
      minSampleFraction: num("minBackgroundFraction", 0),
      deviation:         num("deviation", 0),
      unbalance:         num("unbalance", 0),
      samples:           []
   };

   var table = P.samples;
   if (table && table.length !== undefined && table.length > 0) {
      var maxCoord = 0;
      for (var k = 0; k < table.length; k++) {
         var row0 = table[k];
         if (row0 && row0.length >= 2) {
            if (row0[0] > maxCoord) maxCoord = row0[0];
            if (row0[1] > maxCoord) maxCoord = row0[1];
         }
      }
      var normalized = (maxCoord <= 1.5);
      var chCount = numChannels || 3;
      var tailLen = 2 * chCount;

      for (var i = 0; i < table.length; i++) {
         var row = table[i];
         if (!row || row.length < 2) continue;
         var x = row[0], y = row[1];

         var values = [], weights = [], minWeight = null;
         if (row.length >= 3 + tailLen) {
            var tailStart = row.length - tailLen;
            for (var c = 0; c < chCount; c++) {
               var v = row[tailStart + c * 2];
               var w = row[tailStart + c * 2 + 1];
               values.push(v); weights.push(w);
               if (minWeight === null || w < minWeight) minWeight = w;
            }
         }
         params.samples.push({
            center_x: normalized ? x * imgW : x,
            center_y: normalized ? y * imgH : y,
            radius: (row.length > 2) ? row[2] : 0,
            values: values, weights: weights, minWeight: minWeight, raw: row
         });
      }
   }
   return params;
}

function analyzeSampleDistribution(samples, imgW, imgH, minSampleWeight) {
   if (samples.length === 0) return { count: 0, warning: "no_samples" };
   var weightThreshold = (typeof minSampleWeight === "number") ? minSampleWeight : 0.75;

   var quadrants = {}, weakQuadrants = {};
   var qCols = 4, qRows = 4;
   for (var r = 0; r < qRows; r++)
      for (var c = 0; c < qCols; c++) { quadrants[r + "_" + c] = 0; weakQuadrants[r + "_" + c] = 0; }

   var weakSamples = [];
   for (var i = 0; i < samples.length; i++) {
      var s = samples[i];
      var qc = Math.min(Math.floor(s.center_x / imgW * qCols), qCols - 1);
      var qr = Math.min(Math.floor(s.center_y / imgH * qRows), qRows - 1);
      quadrants[qr + "_" + qc]++;
      if (s.minWeight !== null && s.minWeight !== undefined && s.minWeight < weightThreshold) {
         weakQuadrants[qr + "_" + qc]++;
         weakSamples.push({ center_x: s.center_x, center_y: s.center_y, minWeight: s.minWeight, weights: s.weights });
      }
   }

   var emptyQuadrants = [], minCount = Infinity, maxCount = 0;
   for (var key in quadrants) {
      if (quadrants[key] === 0) emptyQuadrants.push(key);
      minCount = Math.min(minCount, quadrants[key]);
      maxCount = Math.max(maxCount, quadrants[key]);
   }

   var margin = 0.10, edgeCount = 0;
   for (var i = 0; i < samples.length; i++) {
      var s = samples[i];
      var nx = s.center_x / imgW, ny = s.center_y / imgH;
      if (nx < margin || nx > 1 - margin || ny < margin || ny > 1 - margin) edgeCount++;
   }

   return {
      totalCount: samples.length, quadrantCounts: quadrants, emptyQuadrants: emptyQuadrants,
      uniformityRatio: (maxCount > 0) ? minCount / maxCount : 0,
      edgeCoverage: samples.length > 0 ? edgeCount / samples.length : 0,
      weightThreshold: weightThreshold, weakSampleCount: weakSamples.length,
      weakQuadrantCounts: weakQuadrants, weakSamples: weakSamples
   };
}

/**
 * 計算影像上某 sample 位置（正方形區域）的每通道中位數背景估計值。
 * 用途：executeOn() 直接執行 DBE 時「不會」像對話框那樣重新取樣計算
 * sample 的數值與權重，值/權重為 0 的 sample 會被視為未定義而整批忽略
 * （實測錯誤訊息：less than three background samples defined）。
 * 因此腳本必須自己把背景估計值算好填進去、權重填 1。
 */
function computeSampleValues(img, cx, cy, radius, numChannels) {
   return computeAreaStats(img, cx, cy, radius, numChannels).median;
}

/**
 * 計算指定正方形區域的每通道中位數與 MAD。
 */
function computeAreaStats(img, cx, cy, radius, numChannels) {
   var x0 = Math.max(0, Math.round(cx - radius));
   var y0 = Math.max(0, Math.round(cy - radius));
   var x1 = Math.min(img.width,  Math.round(cx + radius));
   var y1 = Math.min(img.height, Math.round(cy + radius));
   var median = [], mad = [];
   img.selectedRect = new Rect(x0, y0, x1, y1);
   for (var c = 0; c < numChannels; c++) {
      img.selectedChannel = c;
      median.push(img.median());
      mad.push(img.MAD());
   }
   img.resetSelections();
   return { median: median, MAD: mad };
}

// 統計本次執行中被降權的 sample 數（僅供 Console 摘要）
var gDeweightedSamples = 0;

/**
 * 組一列完整的 sample row：
 *   [x(px,int), y(px,int), radius, ...meta..., (值,權重) x 通道數]
 * 座標欄位為像素整數（實測：寫入小數會被截斷成整數）。
 *
 * 抗污染設計（重要）：executeOn() 不會像 DBE 對話框那樣以 tolerance
 * 重新評估 sample，若取樣點恰好落在星雲/星暈上，被墊高的色版值會讓
 * 樣條模型局部隆起，扣除後在當地留下反色斑點（實測：落在星雲帶上的
 * 點造成綠/藍被扣過頭，輸出出現紅色斑點）。因此：
 *   1) 取樣前先在原位置附近（半徑 2 倍步距的 9 宮格）找「最暗」的
 *      候選位置——背景是局部最暗的平滑處，星雲/星點只會墊高數值；
 *      鄰近範圍內的真實梯度差異遠小於訊號污染，不影響梯度建模
 *   2) 取樣後與周邊大範圍（4 倍半徑）背景比較，某色版仍明顯偏高
 *      （> k×MAD）代表整片都是訊號（例如大面積星雲內部），把該色版
 *      權重調低，讓模型改由鄰近乾淨 sample 主導
 */
function buildSampleRow(img, cx, cy, radius, metaTemplate, numChannels) {
   // ── 1) 9 宮格找局部最乾淨（最暗）的位置 ──
   var offsets = [[0,0],[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
   var step = radius * 2;
   var bestX = cx, bestY = cy, bestValues = null, bestScore = Infinity;
   for (var i = 0; i < offsets.length; i++) {
      var nx = Math.min(Math.max(cx + offsets[i][0] * step, radius), img.width - radius);
      var ny = Math.min(Math.max(cy + offsets[i][1] * step, radius), img.height - radius);
      var vals = computeSampleValues(img, nx, ny, radius, numChannels);
      var score = 0;
      for (var c = 0; c < numChannels; c++) score += vals[c];
      if (score < bestScore) {
         bestScore = score; bestX = nx; bestY = ny; bestValues = vals;
      }
   }

   // ── 2) 與周邊大範圍背景比較，逐色版評估污染程度 → 降權 ──
   var ref = computeAreaStats(img, bestX, bestY, radius * 4, numChannels);
   var row = [Math.round(bestX), Math.round(bestY), radius].concat(metaTemplate);
   var deweighted = false;
   for (var c = 0; c < numChannels; c++) {
      var sigma = Math.max(ref.MAD[c] * 1.4826, 1e-7);
      var dev = (bestValues[c] - ref.median[c]) / sigma;
      var w;
      if (dev <= 1.5)      w = 1;    // 與周邊背景一致 → 完全信任
      else if (dev <= 3.0) w = 0.3;  // 略偏高 → 降權
      else                 w = 0.05; // 明顯是訊號 → 幾乎不採信
      if (w < 1) deweighted = true;
      row.push(bestValues[c]); // 背景估計值：該區域的中位數
      row.push(w);
   }
   if (deweighted) gDeweightedSamples++;
   return row;
}

/**
 * 由 samples 表產生 data 表。
 * 從 toSource() 反推的關鍵事實：DBE 執行（executeOn）時實際用來建模的是
 * `data` 表（欄位：x, y, z0, w0, z1, w1, ...），`samples` 表只是互動介面
 * 上畫 sample 圈圈用的定義；data 為空時就會報
 * "less than three background samples defined"。
 * samples 列格式：[x(px,int), y(px,int), radius, symmetries, axialCount, isFixed, (z,w) x 通道]
 * data 列格式：   [x(正規化0..1), y(正規化0..1), (z,w) x 通道]
 * 注意兩張表的座標單位不同：samples 是像素整數，data 是正規化小數
 * （實測把像素值塞進 data 會報 "numeric value out of range"）。
 */
function samplesToData(table, numChannels, imgW, imgH) {
   var data = [];
   var tailLen = 2 * numChannels;
   for (var i = 0; i < table.length; i++) {
      var row = table[i];
      if (!row || row.length < 2 + tailLen) continue;
      data.push([row[0] / imgW, row[1] / imgH].concat(row.slice(row.length - tailLen)));
   }
   return data;
}

/**
 * 把 samples/data/通道數一次設定到 DBE instance 上。
 */
function assignSamples(P, table, numChannels, imgW, imgH) {
   P.numberOfChannels = numChannels;
   P.samples = table;
   P.data = samplesToData(table, numChannels, imgW, imgH);
}

/**
 * 產生初始網格 sample table（給第一次「初始 DBE」使用）。
 * 組成 = 內部 N x N 網格 + 沿影像四周貼邊的一圈 sample。
 *
 * 貼邊那一圈很重要：surface spline 在「最外圈 sample 之外」的區域只能
 * 外插，模型最容易失準的就是四邊與四角（實測會留下左右兩側的殘留
 * 色偏梯度）。因此在距邊 2.5% 處補一圈取樣點，讓邊緣有實際資料可依。
 */
function buildInitialSampleGrid(img, imgW, imgH, perRow, radius, numChannels) {
   var metaTemplate = [0, 6, 0]; // 保底猜測值，同 DBEAutoApply.js
   var table = [];

   // ── 內部網格（留 8% 邊界，與貼邊圈保持距離、避免點擠在一起）──
   var marginFrac = 0.08;
   var x0 = imgW * marginFrac, x1 = imgW * (1 - marginFrac);
   var y0 = imgH * marginFrac, y1 = imgH * (1 - marginFrac);
   var pts = spreadPoints({ x0: x0, y0: y0, x1: x1, y1: y1 }, perRow * perRow);
   for (var i = 0; i < pts.length; i++)
      table.push(buildSampleRow(img, pts[i].x, pts[i].y, radius, metaTemplate, numChannels));

   // ── 貼邊圈（距邊 2.5%，含四角）──
   var edge = 0.025;
   var ex0 = imgW * edge, ex1 = imgW * (1 - edge);
   var ey0 = imgH * edge, ey1 = imgH * (1 - edge);
   var nAcross = perRow + 2; // 上下兩邊各 nAcross 點（含四角）
   for (var i = 0; i < nAcross; i++) {
      var fx = ex0 + (ex1 - ex0) * i / (nAcross - 1);
      table.push(buildSampleRow(img, fx, ey0, radius, metaTemplate, numChannels));
      table.push(buildSampleRow(img, fx, ey1, radius, metaTemplate, numChannels));
   }
   var nDown = Math.max(2, perRow); // 左右兩邊（不含已放過的四角）
   for (var i = 1; i < nDown - 1; i++) {
      var fy = ey0 + (ey1 - ey0) * i / (nDown - 1);
      table.push(buildSampleRow(img, ex0, fy, radius, metaTemplate, numChannels));
      table.push(buildSampleRow(img, ex1, fy, radius, metaTemplate, numChannels));
   }

   return table;
}

/**
 * 依 AI 建議的 sample_point_actions，把「目前 samples」改寫成新的 table。
 * @param {Array} currentSamples  extractDBEParams() 回傳的 samples（含 raw）
 * @param {Object} report         dbe_advisor.py 回傳的 AI 建議 JSON
 * @param {Number} sampleRadius   新增 sample 使用的半徑
 * @param {Number} numChannels
 * @param {Image}  srcImg         原始影像（用來計算新增 sample 的背景估計值）
 * @returns {Object} { table, keptCount, removedCount, addedCount, unparsedNotes }
 */
function applySampleActions(currentSamples, report, sampleRadius, numChannels, srcImg) {
   var actions = report.sample_point_actions || [];
   var removeBoxes = [], addPoints = [], unparsedNotes = [];

   for (var i = 0; i < actions.length; i++) {
      var a = actions[i];
      var box = parseRegion(a.region);
      if (!box) { unparsedNotes.push("#" + (i + 1) + " [" + a.action + "] " + a.region); continue; }
      if (a.action === "remove") {
         removeBoxes.push(box);
      } else if (a.action === "add") {
         var n = guessCount(a.reason, 2);
         var pts = spreadPoints(box, n);
         for (var k = 0; k < pts.length; k++)
            addPoints.push({ x: pts[k].x, y: pts[k].y });
      } else if (a.action === "move") {
         var pts2 = spreadPoints(box, 1);
         addPoints.push({ x: pts2[0].x, y: pts2[0].y });
      }
   }

   function inAnyBox(x, y) {
      for (var i = 0; i < removeBoxes.length; i++) {
         var b = removeBoxes[i];
         if (x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1) return true;
      }
      return false;
   }

   var metaTemplate = [0, 6, 0];
   var tailLen = 2 * numChannels;
   for (var i = 0; i < currentSamples.length; i++) {
      var raw = currentSamples[i].raw;
      if (raw && raw.length >= 3 + tailLen) {
         metaTemplate = raw.slice(3, raw.length - tailLen);
         break;
      }
   }

   var table = [], keptCount = 0, removedCount = 0;
   for (var i = 0; i < currentSamples.length; i++) {
      var s = currentSamples[i];
      if (inAnyBox(s.center_x, s.center_y)) { removedCount++; continue; }
      if (s.raw) { table.push(s.raw); keptCount++; }
   }
   for (var i = 0; i < addPoints.length; i++) {
      var p = addPoints[i];
      table.push(buildSampleRow(srcImg, p.x, p.y, sampleRadius, metaTemplate, numChannels));
   }

   return { table: table, keptCount: keptCount, removedCount: removedCount,
            addedCount: addPoints.length, unparsedNotes: unparsedNotes };
}

/**
 * 依 AI 的 parameter_suggestions 設定 DBE 參數，回傳套用摘要文字陣列。
 */
function applyParameterSuggestions(P, pSugg) {
   var changes = [];
   function applyParam(reportKey, propNames) {
      var entry = pSugg[reportKey];
      if (!entry || typeof entry.suggested !== "number") return;
      var applied = setByExistingName(P, propNames, entry.suggested);
      if (applied)
         changes.push(reportKey + " (" + applied + "): " + entry.current + " → " + entry.suggested);
      else
         console.warningln("找不到對應屬性可套用 " + reportKey + "，已略過。");
   }
   applyParam("tolerance",         ["tolerance"]);
   applyParam("shadowsRelaxation", ["shadowsRelaxation"]);
   applyParam("smoothingFactor",   ["smoothing", "smoothFactor"]);
   applyParam("samplesPerRow",     ["samplesPerRow"]);
   return changes;
}

/**
 * Midtones Transfer Function（STF 自動拉伸用）
 */
function mtf(m, x) {
   if (x <= 0) return 0;
   if (x >= 1) return 1;
   return ((m - 1) * x) / (((2 * m - 1) * x) - m);
}

/**
 * 對 view 套用 STF AutoStretch（等同按 Ctrl+A）。
 * 線性影像扣完背景後像素值極接近 0，不拉伸看起來就是全黑，
 * 這裡自動套用讓結果一開視窗就看得到。只影響螢幕顯示，不改像素資料。
 */
function applyAutoSTF(view) {
   var img = view.image;
   var shadowsClipping = -2.80;   // 與 PixInsight 預設 AutoStretch 相同
   var targetBackground = 0.25;
   var n = img.numberOfChannels;
   var medSum = 0, madSum = 0;
   for (var c = 0; c < n; c++) {
      img.selectedChannel = c;
      medSum += img.median();
      madSum += img.MAD() * 1.4826; // 正規化 MAD
   }
   img.resetSelections();
   var med = medSum / n, mad = madSum / n;
   var c0 = Math.min(Math.max(med + shadowsClipping * mad, 0), 1);
   var m = mtf(targetBackground, med - c0);
   view.stf = [ // c0, c1, m, r0, r1（三色版連動 + luminance 列維持恆等）
      [c0, 1, m, 0, 1],
      [c0, 1, m, 0, 1],
      [c0, 1, m, 0, 1],
      [0, 1, 0.5, 0, 1]
   ];
}

/**
 * HTML 跳脫
 */
function htmlEscape(s) {
   return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
                   .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/**
 * 從殘差網格整理摘要：全域均值、範圍、偏離最大的前 5 區域。
 * 這些就是送給 AI 判斷的核心證據，報告裡要讓使用者看得到。
 */
function summarizeResidualGrid(grid) {
   var cells = [];
   for (var r = 0; r < grid.length; r++)
      for (var c = 0; c < grid[r].length; c++)
         cells.push(grid[r][c]);
   if (cells.length === 0) return null;

   var sum = 0, minMean = Infinity, maxMean = -Infinity;
   for (var i = 0; i < cells.length; i++) {
      sum += cells[i].mean;
      if (cells[i].mean < minMean) minMean = cells[i].mean;
      if (cells[i].mean > maxMean) maxMean = cells[i].mean;
   }
   var globalMean = sum / cells.length;

   var devs = [];
   for (var i = 0; i < cells.length; i++) {
      devs.push({
         x0: cells[i].x0, y0: cells[i].y0, x1: cells[i].x1, y1: cells[i].y1,
         mean: cells[i].mean,
         dev: Math.abs(cells[i].mean - globalMean)
      });
   }
   devs.sort(function(a, b) { return b.dev - a.dev; });

   return {
      globalMean: globalMean, minMean: minMean, maxMean: maxMean,
      topDeviations: devs.slice(0, 5)
   };
}

/**
 * 產生 .txt 與 .html 兩種格式的調整說明報告。
 * 報告設計原則：讓使用者不用懂程式也能看懂「DBE 是怎麼處理這張圖的」——
 * 依「量測了什麼數據 → 據此做了什麼判斷 → 執行了什麼調整」的因果順序呈現。
 * @param {Object} ctx  彙整好的報告資料（見 main 內的組裝處）
 * @returns {Object} { txt, html }
 */
function buildReports(ctx) {
   var report = ctx.report;
   var issues = report.issues || [];
   var pSuggAll = report.parameter_suggestions || {};
   var sActions = report.sample_point_actions || [];
   var steps = report.next_steps || [];
   var res = ctx.residualSummary;
   var dist = ctx.sampleDistribution;

   var sevName = { high: "高", medium: "中", low: "低" };

   // ── 各章節內容先組成中性的資料結構，txt/html 各自渲染 ──

   var flowSteps = [
      "自動佈點：在影像內部放置 " + ctx.gridCount + " 個網格取樣點（避開 8% 邊界），" +
         "並沿影像四周距邊 2.5% 處加放 " + ctx.edgeCount + " 個貼邊取樣點（含四角）。" +
         "貼邊點的目的：背景模型（surface spline）在最外圈取樣點之外只能外插，" +
         "不貼邊取樣的話，影像邊緣的梯度校正最容易失準。",
      "初步取樣：每個取樣點讀取半徑 " + ctx.sampleRadius + " px 範圍內各色版的「中位數」" +
         "作為該點背景估計值（中位數可抵抗星點干擾），執行第一次 DBE 產生初步背景模型。",
      "殘差量測：計算「原圖 − 初步背景模型」的殘差，切成 " + ctx.residGridN + "x" + ctx.residGridN +
         " 網格逐格統計。殘差不均勻的位置＝初步模型沒校正好的位置，這是後續所有判斷的依據。",
      "AI 分析：把殘差統計、取樣點分佈、拍攝條件（Bortle " + ctx.bortleScale + "、" +
         ctx.filterName + " 濾鏡、" + ctx.cameraLabel + "）送交 " + ctx.model +
         " 分析，取得問題清單與調整建議" +
         "（AI 只分析數據、給出建議，不接觸任何像素）。",
      "套用與執行：依建議調整取樣點與參數後，在原圖的複製品上執行最終 DBE，" +
         "以減法（Subtraction）扣除背景模型並加回背景中位數（Normalize）。原圖全程未被更動。",
      "驗證與迭代：對校正後影像重新自動佈點取樣，量測「背景取樣點背景值的離散度」" +
         "並以固定公式計算客觀分數（滿分 100，本次目標 " + ctx.targetScore + " 分）。" +
         "取樣點是局部最暗的乾淨背景，星雲/星點訊號不會污染此指標。未達標時把驗證數據" +
         "回饋給 AI 再修正、重跑（本次共執行 " + ctx.iterationHistory.length + " 輪），" +
         "最後保留分數最高的一輪。分數由公式計算，跨模型、跨次執行可直接比較。"
   ];

   // ── TXT ──
   var t = "";
   t += "============================================================\n";
   t += " DBE Auto Pilot 調整說明\n";
   t += " 時間: " + ctx.ts + "\n";
   t += " 來源影像: " + ctx.srcId + " (" + ctx.imgW + "x" + ctx.imgH + ", " + ctx.numCh + " ch)\n";
   t += " 拍攝條件: Bortle " + ctx.bortleScale + ", 濾鏡 " + ctx.filterName +
        ", " + ctx.cameraLabel + "\n";
   t += " 分析模型: " + ctx.model + " (effort=" + ctx.effort + ")\n";
   t += "============================================================\n\n";

   t += "【DBE 是怎麼處理這張圖的（處理流程）】\n";
   for (var i = 0; i < flowSteps.length; i++)
      t += "步驟 " + (i + 1) + "：" + flowSteps[i] + "\n\n";

   t += "【量測到的診斷數據（所有判斷的依據）】\n";
   if (res) {
      t += "殘差網格（原圖 − 初步背景模型，理想情況各區域應接近一致）:\n";
      t += "- 全域殘差均值: " + res.globalMean.toFixed(8) + "\n";
      t += "- 殘差範圍: [" + res.minMean.toFixed(8) + ", " + res.maxMean.toFixed(8) + "]\n";
      t += "- 偏離最大的 5 個區域（殘留梯度所在，像素座標）:\n";
      for (var i = 0; i < res.topDeviations.length; i++) {
         var d = res.topDeviations[i];
         t += "  " + (i + 1) + ". (" + d.x0 + " px, " + d.y0 + " px) ~ (" +
              d.x1 + " px, " + d.y1 + " px)  殘差=" + d.mean.toFixed(8) +
              "（偏離 " + d.dev.toFixed(8) + "）\n";
      }
   }
   if (dist) {
      t += "取樣點分佈品質:\n";
      t += "- 總數: " + dist.totalCount +
           "，均勻性: " + (dist.uniformityRatio || 0).toFixed(2) + "（1.0=完美均勻）" +
           "，邊緣覆蓋率: " + (dist.edgeCoverage || 0).toFixed(2) + "（理想 0.3-0.5）\n";
      t += "- 空白象限: " + JSON.stringify(dist.emptyQuadrants || []) +
           "，權重過低（形同虛設）的取樣點: " + (dist.weakSampleCount || 0) + " 個\n";
   }
   t += "\n";

   var obj = ctx.objective;
   var histParts = [];
   for (var i = 0; i < ctx.iterationHistory.length; i++)
      histParts.push("第 " + ctx.iterationHistory[i].attempt + " 輪 " +
                     ctx.iterationHistory[i].score + " 分");

   t += "【客觀評分（腳本公式計算，非 AI 主觀評分）】\n";
   t += "最終分數: " + obj.score + "/100（目標 " + ctx.targetScore + " 分" +
        (obj.score >= ctx.targetScore ? "，已達標" : "，未達標，保留分數最高的一輪") + "）\n";
   t += "- 背景平坦度扣分: " + obj.flatness.deduction +
        "（取樣點背景值峰谷差 " + obj.flatness.pv.toFixed(8) +
        " = 雜訊 sigma 的 " + obj.flatness.ratio.toFixed(1) + " 倍；≤3 倍不扣分，滿額 55）\n";
   t += "- 色版平衡扣分: " + obj.channelBalance.deduction +
        "（取樣點最大色版偏移差 " + obj.channelBalance.spread.toFixed(8) +
        " = sigma 的 " + obj.channelBalance.ratio.toFixed(1) + " 倍；≤2 倍不扣分，滿額 25）\n";
   t += "- 取樣品質扣分: " + obj.sampling.deduction +
        ((obj.sampling.notes && obj.sampling.notes.length > 0)
           ? "（" + obj.sampling.notes.join("；") + "）" : "（無扣分項，滿額 20）") + "\n";
   t += "- 迭代歷程: 初始設定 " + ctx.initialScore + " 分 → " + histParts.join(" → ") +
        "（採用第 " + ctx.bestAttempt + " 輪結果）\n\n";

   t += "【AI 總評】\n" + report.summary + "\n\n";

   if (issues.length > 0) {
      t += "【AI 發現的問題與判斷理由】\n";
      for (var i = 0; i < issues.length; i++) {
         var iss = issues[i];
         t += (i + 1) + ". [嚴重度: " + (sevName[iss.severity] || iss.severity) + "] " +
              (iss.category || "") + "\n";
         t += "   觀察到的問題: " + (iss.description || "") + "\n";
         t += "   因此採取的對策: " + (iss.suggestion || "") + "\n\n";
      }
   }

   t += "【參數調整明細】\n";
   t += "（「DBE 介面位置」指 Process > BackgroundModelization >\n";
   t += "  DynamicBackgroundExtraction 對話框中對應的設定欄位）\n\n";
   var anyParam = false;
   for (var key in pSuggAll) {
      var entry = pSuggAll[key];
      if (!entry || typeof entry !== "object") continue;
      anyParam = true;
      var changed = (entry.current !== entry.suggested);
      t += "- " + key + ": " + entry.current + " → " + entry.suggested +
           (changed ? "（已調整）" : "（維持不變）") + "\n";
      t += "  DBE 介面位置: " + (PARAM_UI_MAP[key] || "（無對應介面欄位）") + "\n";
      if (entry.reason)
         t += "  調整依據: " + entry.reason + "\n";
   }
   if (!anyParam) t += "（AI 未給出參數建議，全部維持預設）\n";
   t += "\n";

   if (sActions.length > 0) {
      t += "【取樣點調整與依據】\n";
      for (var i = 0; i < sActions.length; i++) {
         var a = sActions[i];
         t += "- [" + (a.action || "?") + "] " + (a.region || "") + "\n";
         if (a.reason) t += "  依據: " + a.reason + "\n";
      }
      t += "\n";
   }
   t += "取樣點統計: 保留 " + ctx.actionResult.keptCount +
        "，移除 " + ctx.actionResult.removedCount +
        "，新增 " + ctx.actionResult.addedCount +
        "，合計 " + ctx.actionResult.table.length + "\n\n";

   t += "【本次執行的固定設定（對應 DBE 介面）】\n";
   t += "- Target Image Correction → Correction: Subtraction（減法扣除光害梯度）\n";
   t += "- Target Image Correction → Normalize: 勾選（扣除後加回背景中位數，維持亮度）\n";
   t += "- Target Image Correction → Discard background model: 不勾選（保留背景模型視窗）\n";
   t += "- Target Image Correction → Replace target image: 勾選（於複製品上就地校正，原圖不動）\n";
   t += "- Sample Generation → Default sample radius: " + ctx.sampleRadius + " px\n\n";

   if (steps.length > 0) {
      t += "【AI 建議的後續步驟】\n";
      for (var i = 0; i < steps.length; i++)
         t += (i + 1) + ". " + steps[i] + "\n";
      t += "\n";
   }

   t += "【產出檔案】\n";
   t += "- 校正後影像視窗: " + ctx.finalId + "\n";
   t += "- 背景模型視窗: " + ctx.finalBgId + "\n";
   t += "- 診斷 JSON: " + ctx.diagPath + "\n";
   t += "- AI 報告 JSON: " + ctx.reportPath + "\n";
   for (var i = 0; i < (ctx.extraFiles || []).length; i++)
      t += "- 迭代檔案: " + ctx.extraFiles[i] + "\n";

   // ── HTML ──
   var sevColor = { high: "#c62828", medium: "#e65100", low: "#2e7d32" };
   var h = "";
   h += "<!DOCTYPE html><html lang='zh-Hant'><head><meta charset='utf-8'>";
   h += "<title>DBE Auto Pilot 調整說明 " + htmlEscape(ctx.ts) + "</title><style>";
   h += "body{font-family:'Microsoft JhengHei',system-ui,sans-serif;max-width:960px;margin:24px auto;padding:0 16px;line-height:1.7;color:#222;background:#fafafa}";
   h += "h1{font-size:1.5em;border-bottom:3px solid #1565c0;padding-bottom:8px}";
   h += "h2{font-size:1.15em;color:#1565c0;margin-top:28px;border-left:4px solid #1565c0;padding-left:10px}";
   h += "table{border-collapse:collapse;width:100%;margin:10px 0;background:#fff}";
   h += "th,td{border:1px solid #ccc;padding:6px 10px;text-align:left;font-size:0.92em}";
   h += "th{background:#e3f2fd}";
   h += "ol.flow li{margin-bottom:10px}";
   h += ".badge{display:inline-block;padding:1px 10px;border-radius:10px;color:#fff;font-size:0.85em}";
   h += ".mono{font-family:Consolas,monospace;font-size:0.9em}";
   h += ".card{background:#fff;border:1px solid #ddd;border-radius:6px;padding:12px 16px;margin:10px 0}";
   h += ".why{color:#555;font-size:0.92em;margin-top:4px}";
   h += ".score{font-size:1.3em;font-weight:bold}";
   h += "</style></head><body>";

   h += "<h1>DBE Auto Pilot 調整說明</h1>";
   h += "<table><tr><th>時間</th><td>" + htmlEscape(ctx.ts) + "</td></tr>";
   h += "<tr><th>來源影像</th><td class='mono'>" + htmlEscape(ctx.srcId) + " (" +
        ctx.imgW + "×" + ctx.imgH + ", " + ctx.numCh + " ch)</td></tr>";
   h += "<tr><th>拍攝條件</th><td>Bortle " + ctx.bortleScale + "，濾鏡 " +
        htmlEscape(ctx.filterName) + "，" + htmlEscape(ctx.cameraLabel) + "</td></tr>";
   h += "<tr><th>分析模型</th><td class='mono'>" + htmlEscape(ctx.model) +
        " (effort=" + htmlEscape(ctx.effort) + ")</td></tr></table>";

   h += "<h2>DBE 是怎麼處理這張圖的（處理流程）</h2><ol class='flow'>";
   for (var i = 0; i < flowSteps.length; i++)
      h += "<li>" + htmlEscape(flowSteps[i]) + "</li>";
   h += "</ol>";

   h += "<h2>量測到的診斷數據（所有判斷的依據）</h2>";
   if (res) {
      h += "<div class='card'><b>殘差網格</b>（原圖 − 初步背景模型；理想情況各區域應接近一致）";
      h += "<table><tr><th>全域殘差均值</th><td class='mono'>" + res.globalMean.toFixed(8) + "</td>";
      h += "<th>殘差範圍</th><td class='mono'>[" + res.minMean.toFixed(8) + ", " +
           res.maxMean.toFixed(8) + "]</td></tr></table>";
      h += "<b>偏離最大的 5 個區域</b>（殘留梯度所在，像素座標）：";
      h += "<table><tr><th>#</th><th>區域</th><th>殘差均值</th><th>偏離全域</th></tr>";
      for (var i = 0; i < res.topDeviations.length; i++) {
         var d = res.topDeviations[i];
         h += "<tr><td>" + (i + 1) + "</td><td class='mono'>(" + d.x0 + ", " + d.y0 +
              ") ~ (" + d.x1 + ", " + d.y1 + ")</td><td class='mono'>" +
              d.mean.toFixed(8) + "</td><td class='mono'>" + d.dev.toFixed(8) + "</td></tr>";
      }
      h += "</table></div>";
   }
   if (dist) {
      h += "<div class='card'><b>取樣點分佈品質</b>";
      h += "<table><tr><th>總數</th><th>均勻性 (1.0=完美)</th><th>邊緣覆蓋率 (理想 0.3-0.5)</th>" +
           "<th>空白象限</th><th>權重過低取樣點</th></tr>";
      h += "<tr><td>" + dist.totalCount + "</td><td>" + (dist.uniformityRatio || 0).toFixed(2) +
           "</td><td>" + (dist.edgeCoverage || 0).toFixed(2) + "</td><td class='mono'>" +
           htmlEscape(JSON.stringify(dist.emptyQuadrants || [])) + "</td><td>" +
           (dist.weakSampleCount || 0) + " 個</td></tr></table></div>";
   }

   h += "<h2>客觀評分（腳本公式計算，非 AI 主觀評分）</h2><div class='card'>";
   h += "<span class='score'>" + obj.score + " / 100</span>（目標 " + ctx.targetScore + " 分" +
        (obj.score >= ctx.targetScore ? "，已達標" : "，未達標，保留分數最高的一輪") + "）";
   h += "<table><tr><th>分項</th><th>扣分</th><th>量測依據</th></tr>";
   h += "<tr><td>背景平坦度（滿額 55）</td><td class='mono'>-" + obj.flatness.deduction +
        "</td><td>取樣點背景值峰谷差 " + obj.flatness.pv.toFixed(8) + " = 雜訊 sigma 的 " +
        obj.flatness.ratio.toFixed(1) + " 倍（≤3 倍不扣分）</td></tr>";
   h += "<tr><td>色版平衡（滿額 25）</td><td class='mono'>-" + obj.channelBalance.deduction +
        "</td><td>取樣點最大色版偏移差 " + obj.channelBalance.spread.toFixed(8) + " = sigma 的 " +
        obj.channelBalance.ratio.toFixed(1) + " 倍（≤2 倍不扣分）</td></tr>";
   h += "<tr><td>取樣品質（滿額 20）</td><td class='mono'>-" + obj.sampling.deduction +
        "</td><td>" + ((obj.sampling.notes && obj.sampling.notes.length > 0)
           ? htmlEscape(obj.sampling.notes.join("；")) : "無扣分項") + "</td></tr></table>";
   h += "<p>迭代歷程：初始設定 " + ctx.initialScore + " 分 → " +
        htmlEscape(histParts.join(" → ")) + "（採用第 " + ctx.bestAttempt + " 輪結果）</p></div>";

   h += "<h2>AI 總評</h2><div class='card'>" + htmlEscape(report.summary) + "</div>";

   if (issues.length > 0) {
      h += "<h2>AI 發現的問題與判斷理由</h2>";
      for (var i = 0; i < issues.length; i++) {
         var iss = issues[i];
         var col = sevColor[iss.severity] || "#616161";
         h += "<div class='card'><span class='badge' style='background:" + col + "'>嚴重度: " +
              htmlEscape(sevName[iss.severity] || iss.severity) + "</span> <b>" +
              htmlEscape(iss.category || "") + "</b>";
         h += "<div>觀察到的問題：" + htmlEscape(iss.description || "") + "</div>";
         h += "<div class='why'>因此採取的對策：" + htmlEscape(iss.suggestion || "") + "</div></div>";
      }
   }

   h += "<h2>參數調整明細</h2>";
   h += "<p>「DBE 介面位置」指 Process &gt; BackgroundModelization &gt; " +
        "DynamicBackgroundExtraction 對話框中對應的設定欄位。</p>";
   h += "<table><tr><th>參數</th><th>DBE 介面位置</th><th>調整</th><th>調整依據</th></tr>";
   var anyParamH = false;
   for (var key in pSuggAll) {
      var entry = pSuggAll[key];
      if (!entry || typeof entry !== "object") continue;
      anyParamH = true;
      var changed = (entry.current !== entry.suggested);
      h += "<tr><td class='mono'>" + htmlEscape(key) + "</td><td>" +
           htmlEscape(PARAM_UI_MAP[key] || "（無對應介面欄位）") + "</td><td class='mono'>" +
           htmlEscape(String(entry.current)) + " → " + htmlEscape(String(entry.suggested)) +
           (changed ? "（已調整）" : "（維持不變）") + "</td><td>" +
           htmlEscape(entry.reason || "") + "</td></tr>";
   }
   if (!anyParamH)
      h += "<tr><td colspan='4'>AI 未給出參數建議，全部維持預設</td></tr>";
   h += "</table>";

   h += "<h2>取樣點調整與依據</h2>";
   if (sActions.length > 0) {
      h += "<table><tr><th>動作</th><th>區域（像素座標）</th><th>依據</th></tr>";
      for (var i = 0; i < sActions.length; i++) {
         var a = sActions[i];
         h += "<tr><td class='mono'>" + htmlEscape(a.action || "?") + "</td><td class='mono'>" +
              htmlEscape(a.region || "") + "</td><td>" + htmlEscape(a.reason || "") + "</td></tr>";
      }
      h += "</table>";
   }
   h += "<p>取樣點統計：保留 " + ctx.actionResult.keptCount + "，移除 " +
        ctx.actionResult.removedCount + "，新增 " + ctx.actionResult.addedCount +
        "，合計 " + ctx.actionResult.table.length + "</p>";

   h += "<h2>本次執行的固定設定（對應 DBE 介面）</h2>";
   h += "<table><tr><th>DBE 介面位置</th><th>設定</th><th>用意</th></tr>";
   h += "<tr><td>Target Image Correction → Correction</td><td class='mono'>Subtraction</td>" +
        "<td>以減法扣除光害梯度（加性梯度最常見的校正方式）</td></tr>";
   h += "<tr><td>Target Image Correction → Normalize</td><td>勾選</td>" +
        "<td>扣除後加回背景中位數，維持整體亮度、避免像素變負值被截為 0</td></tr>";
   h += "<tr><td>Target Image Correction → Discard background model</td><td>不勾選</td>" +
        "<td>保留背景模型視窗供人工檢查（模型應為平滑漸層；若出現雲氣形狀代表扣到真實訊號）</td></tr>";
   h += "<tr><td>Target Image Correction → Replace target image</td><td>勾選</td>" +
        "<td>於複製品上就地校正；原始影像視窗全程未被更動</td></tr>";
   h += "<tr><td>Sample Generation → Default sample radius</td><td class='mono'>" +
        ctx.sampleRadius + " px</td><td>依影像尺寸自動計算（短邊的 2%，限 10-40）</td></tr>";
   h += "</table>";

   if (steps.length > 0) {
      h += "<h2>AI 建議的後續步驟</h2><ol>";
      for (var i = 0; i < steps.length; i++)
         h += "<li>" + htmlEscape(steps[i]) + "</li>";
      h += "</ol>";
   }

   h += "<h2>產出檔案</h2><table>";
   h += "<tr><th>校正後影像視窗</th><td class='mono'>" + htmlEscape(ctx.finalId) + "</td></tr>";
   h += "<tr><th>背景模型視窗</th><td class='mono'>" + htmlEscape(ctx.finalBgId) + "</td></tr>";
   h += "<tr><th>診斷 JSON</th><td class='mono'>" + htmlEscape(ctx.diagPath) + "</td></tr>";
   h += "<tr><th>AI 報告 JSON</th><td class='mono'>" + htmlEscape(ctx.reportPath) + "</td></tr>";
   for (var i = 0; i < (ctx.extraFiles || []).length; i++)
      h += "<tr><th>迭代檔案</th><td class='mono'>" + htmlEscape(ctx.extraFiles[i]) + "</td></tr>";
   h += "</table>";

   h += "<p style='color:#888;font-size:0.85em;margin-top:24px'>本報告由 DBE Auto Pilot v" +
        VERSION + " 自動產生。AI 僅分析統計數據並提供參數建議，影像像素僅經 PixInsight " +
        "DynamicBackgroundExtraction（2D surface spline）之古典演算法處理，無任何生成式處理。</p>";
   h += "</body></html>";

   return { txt: t, html: h };
}

/**
 * 對指定 view 執行 DBE，並抓出新產生的背景模型視窗
 * （用執行前後的視窗列表差異偵測，不依賴猜測命名規則）。
 * @returns {ImageWindow} 背景模型視窗；找不到則丟例外
 */
function runDBEAndCaptureModel(P, targetView) {
   var before = ImageWindow.windows.slice();
   var beforeIds = {};
   for (var i = 0; i < before.length; i++) beforeIds[before[i].mainView.id] = true;

   P.executeOn(targetView);

   var after = ImageWindow.windows;
   var newWindows = [];
   for (var i = 0; i < after.length; i++)
      if (!beforeIds[after[i].mainView.id]) newWindows.push(after[i]);

   if (newWindows.length === 0)
      throw new Error(
         "執行 DBE 後找不到新產生的背景模型視窗。可能是此 PixInsight 版本" +
         "預設不會保留背景模型（或屬性名稱與腳本假設不同），已中止以避免" +
         "用錯誤資料繼續分析。請手動確認 DBE 對話框裡「Discard background model」" +
         "是否被勾選。"
      );
   // 理論上只會多一個（背景模型），若多於一個，取第一個並警告
   if (newWindows.length > 1)
      console.warningln("偵測到多個新視窗，預期為背景模型，取第一個：" + newWindows[0].mainView.id);

   return newWindows[0];
}

/**
 * 對指定 view 重新自動佈點取樣（與步驟 1 相同的佈點邏輯），供
 * computeObjectiveScore 量測「背景取樣點離散度」。量測方法一致，
 * 迭代前後的客觀分數才可以互相比較。
 *
 * 不需要執行 DBE：取樣點本身的背景值就是量測對象（局部最暗乾淨背景，
 * 星雲/星點不會污染），也避免了在同一 session 對 replaceTarget 後的
 * 影像再跑 DBE（實測 headless 環境下偶發崩潰）。
 * @returns {Object} { table, stats }  sample table 與該影像各通道統計
 */
function measureSampleDispersion(view, gridPerRow, sampleRadius, numCh) {
   var img = view.image;
   // 量測用的降權計數不應計入主流程的統計
   var savedDeweighted = gDeweightedSamples;
   try {
      var table = buildInitialSampleGrid(img, img.width, img.height, gridPerRow, sampleRadius, numCh);
      var stats = [];
      for (var ch = 0; ch < numCh; ch++) stats.push(channelStats(img, ch));
      return { table: table, stats: stats };
   } finally {
      gDeweightedSamples = savedDeweighted;
   }
}

// ─────────────────────────────────────────────
// 對話框 UI
// ─────────────────────────────────────────────

function DBEAutoPilotDialog() {
   this.__base__ = Dialog;
   this.__base__();
   this.windowTitle = TITLE + " v" + VERSION;

   this.srcLabel = new Label(this);
   this.srcLabel.text = "選擇剛疊好的影像（尚未做過 DBE）:";
   this.srcViewList = new ViewList(this);
   this.srcViewList.getMainViews();

   this.apiKeyLabel = new Label(this);
   this.apiKeyLabel.text = "Anthropic API Key（sk-ant-...，只需輸入一次，會記住）:";
   this.apiKeyEdit = new Edit(this);
   this.apiKeyEdit.text = loadSetting("apiKey", "");
   this.apiKeyEdit.setMinWidth(480);
   this.apiKeyEdit.toolTip = "至 console.anthropic.com 取得。以 PixInsight Settings 儲存於本機。";

   this.outDirLabel = new Label(this);
   this.outDirLabel.text = "報告輸出目錄（診斷/報告 JSON、TXT、HTML）:";
   this.outDirEdit = new Edit(this);
   this.outDirEdit.text = loadSetting("outputDir", defaultOutputDir());
   this.outDirEdit.setMinWidth(480);

   this.gridLabel = new Label(this);
   this.gridLabel.text = "初始 sample 網格（N x N）:";
   this.gridSpinBox = new SpinBox(this);
   this.gridSpinBox.minValue = 3;
   this.gridSpinBox.maxValue = 12;
   this.gridSpinBox.value = 6;

   this.residGridLabel = new Label(this);
   this.residGridLabel.text = "殘差分析網格（N x N）:";
   this.residGridSpinBox = new SpinBox(this);
   this.residGridSpinBox.minValue = 4;
   this.residGridSpinBox.maxValue = 16;
   this.residGridSpinBox.value = 8;

   this.bortleLabel = new Label(this);
   this.bortleLabel.text = "拍攝地 Bortle 等級:";
   this.bortleCombo = new ComboBox(this);
   this.bortleCombo.addItem("1 - 極暗空");
   this.bortleCombo.addItem("2 - 典型暗空");
   this.bortleCombo.addItem("3 - 鄉村空");
   this.bortleCombo.addItem("4 - 鄉村/郊區過渡");
   this.bortleCombo.addItem("5 - 郊區空");
   this.bortleCombo.addItem("6 - 明亮郊區空");
   this.bortleCombo.addItem("7 - 郊區/城市過渡");
   this.bortleCombo.addItem("8 - 城市空");
   this.bortleCombo.addItem("9 - 市中心空");
   this.bortleCombo.currentItem = 4;

   this.filterLabel = new Label(this);
   this.filterLabel.text = "使用濾鏡（自行輸入，例如 Askar D1、L-eXtreme；沒用濾鏡就留空）:";
   this.filterEdit = new Edit(this);
   this.filterEdit.text = loadSetting("filter", "");
   this.filterEdit.setMinWidth(480);
   this.filterEdit.toolTip = "輸入的濾鏡名稱會原樣提供給 AI，作為梯度/色版失衡分析的依據；會記住上次輸入";

   this.cameraLabel = new Label(this);
   this.cameraLabel.text = "相機類型:";
   this.cameraCombo = new ComboBox(this);
   this.cameraCombo.addItem("彩色（OSC / DSLR）");
   this.cameraCombo.addItem("單色（Mono + 濾鏡輪）");
   this.cameraCombo.currentItem = (loadSetting("cameraType", "color") === "mono") ? 1 : 0;
   this.cameraCombo.toolTip = "影響 AI 對色版失衡成因的判斷；會記住上次選擇";

   this.contextLabel = new Label(this);
   this.contextLabel.text = "附加說明（選填，例如「Ha 窄帶 3nm」）:";
   this.contextEdit = new Edit(this);
   this.contextEdit.setMinWidth(480);

   this.modelLabel = new Label(this);
   this.modelLabel.text = "Claude 模型（清單來自 Anthropic API；離線時用預設清單）:";
   this.modelCombo = new ComboBox(this);
   this.modelCombo.editEnabled = true; // 也允許手動輸入清單外的模型 id
   this.modelCombo.setMinWidth(280);

   var self = this;
   this.populateModels = function(forceRefresh) {
      var savedModel = loadSetting("model", "claude-opus-4-6");
      var models = getModelList(self.apiKeyEdit.text.trim(), forceRefresh);
      if (models.indexOf(savedModel) < 0) models.unshift(savedModel);
      self.modelCombo.clear();
      for (var i = 0; i < models.length; i++) self.modelCombo.addItem(models[i]);
      self.modelCombo.currentItem = models.indexOf(savedModel);
      self.modelCombo.editText = savedModel;
   };
   this.populateModels(false);

   this.modelRefreshButton = new PushButton(this);
   this.modelRefreshButton.text = "更新模型清單";
   this.modelRefreshButton.toolTip = "以上方 API Key 連網查詢最新可用模型（需網路）";
   this.modelRefreshButton.onClick = function() {
      this.dialog.populateModels(true);
   };

   this.modelSizer = new HorizontalSizer;
   this.modelSizer.add(this.modelCombo, 100);
   this.modelSizer.addSpacing(6);
   this.modelSizer.add(this.modelRefreshButton);

   this.effortLabel = new Label(this);
   this.effortLabel.text = "分析深度 (effort):";
   this.effortCombo = new ComboBox(this);
   this.effortCombo.addItem("low");
   this.effortCombo.addItem("medium");
   this.effortCombo.addItem("high");
   this.effortCombo.addItem("max");
   this.effortCombo.currentItem = 1; // medium

   this.timeoutLabel = new Label(this);
   this.timeoutLabel.text = "呼叫逾時秒數:";
   this.timeoutSpinBox = new SpinBox(this);
   this.timeoutSpinBox.minValue = 30;
   this.timeoutSpinBox.maxValue = 900;
   this.timeoutSpinBox.value = 180;

   this.targetScoreLabel = new Label(this);
   this.targetScoreLabel.text = "目標分數（客觀評分，未達標會自動迭代修正）:";
   this.targetScoreSpinBox = new SpinBox(this);
   this.targetScoreSpinBox.minValue = 50;
   this.targetScoreSpinBox.maxValue = 95;
   this.targetScoreSpinBox.value = 80;
   this.targetScoreSpinBox.toolTip =
      "分數由腳本以固定公式從殘差量測計算（非 AI 主觀評分）。\n" +
      "每輪執行完 DBE 會重新量測，未達標就把數據回饋給 AI 再修正重跑。";

   this.maxIterLabel = new Label(this);
   this.maxIterLabel.text = "最多迭代輪數（每輪多一次 AI 呼叫與 DBE 執行）:";
   this.maxIterSpinBox = new SpinBox(this);
   this.maxIterSpinBox.minValue = 1;
   this.maxIterSpinBox.maxValue = 5;
   this.maxIterSpinBox.value = 3;
   this.maxIterSpinBox.toolTip =
      "達標即提前停止；跑滿仍未達標時保留分數最高的一輪結果。";

   this.okButton = new PushButton(this);
   this.okButton.text = "開始全自動流程";
   this.okButton.onClick = function() { this.dialog.ok(); };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "取消";
   this.cancelButton.onClick = function() { this.dialog.cancel(); };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.okButton);
   this.buttonsSizer.addSpacing(8);
   this.buttonsSizer.add(this.cancelButton);

   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 6;
   this.sizer.add(this.srcLabel);
   this.sizer.add(this.srcViewList);
   this.sizer.add(this.apiKeyLabel);
   this.sizer.add(this.apiKeyEdit);
   this.sizer.add(this.outDirLabel);
   this.sizer.add(this.outDirEdit);
   this.sizer.add(this.gridLabel);
   this.sizer.add(this.gridSpinBox);
   this.sizer.add(this.residGridLabel);
   this.sizer.add(this.residGridSpinBox);
   this.sizer.add(this.bortleLabel);
   this.sizer.add(this.bortleCombo);
   this.sizer.add(this.filterLabel);
   this.sizer.add(this.filterEdit);
   this.sizer.add(this.cameraLabel);
   this.sizer.add(this.cameraCombo);
   this.sizer.add(this.contextLabel);
   this.sizer.add(this.contextEdit);
   this.sizer.add(this.modelLabel);
   this.sizer.add(this.modelSizer);
   this.sizer.add(this.effortLabel);
   this.sizer.add(this.effortCombo);
   this.sizer.add(this.timeoutLabel);
   this.sizer.add(this.timeoutSpinBox);
   this.sizer.add(this.targetScoreLabel);
   this.sizer.add(this.targetScoreSpinBox);
   this.sizer.add(this.maxIterLabel);
   this.sizer.add(this.maxIterSpinBox);
   this.sizer.addSpacing(12);
   this.sizer.add(this.buttonsSizer);

   this.adjustToContents();
}
DBEAutoPilotDialog.prototype = new Dialog;

// ─────────────────────────────────────────────
// 主程式
// ─────────────────────────────────────────────

function main() {
   var dlg = new DBEAutoPilotDialog();
   if (dlg.execute() !== StdButton_Ok) return;

   var srcView = dlg.srcViewList.currentView;
   if (srcView.isNull) {
      (new MessageBox("請選擇一個影像。", TITLE, StdIcon_Error)).execute();
      return;
   }

   var apiKey      = dlg.apiKeyEdit.text.trim();
   var outputDir   = dlg.outDirEdit.text.trim() || defaultOutputDir();
   var gridPerRow  = dlg.gridSpinBox.value;
   var residGridN  = dlg.residGridSpinBox.value;
   var bortleScale = dlg.bortleCombo.currentItem + 1;
   var filterName  = dlg.filterEdit.text.trim() || "None";
   var cameraType  = (dlg.cameraCombo.currentItem === 1) ? "mono" : "color";
   var extraContext = dlg.contextEdit.text.trim();
   var model  = dlg.modelCombo.editText.trim() || "claude-opus-4-6";
   var effort = ["low", "medium", "high", "max"][dlg.effortCombo.currentItem];
   var timeoutSec = dlg.timeoutSpinBox.value;
   var targetScore = dlg.targetScoreSpinBox.value;
   var maxAttempts = dlg.maxIterSpinBox.value;

   if (!apiKey) {
      (new MessageBox("請輸入 Anthropic API Key（sk-ant-...）。\n" +
                      "可至 console.anthropic.com 取得。", TITLE, StdIcon_Error)).execute();
      return;
   }

   // 記住使用者設定，下次不用重填
   saveSetting("apiKey", apiKey);
   saveSetting("outputDir", outputDir);
   saveSetting("filter", dlg.filterEdit.text.trim());
   saveSetting("cameraType", cameraType);
   saveSetting("model", model);

   // 確保輸出目錄存在
   if (!File.directoryExists(outputDir)) {
      try { File.createDirectory(outputDir, true); }
      catch (e) {
         (new MessageBox("無法建立輸出目錄：" + outputDir + "\n" + e,
                         TITLE, StdIcon_Error)).execute();
         return;
      }
   }

   var srcId = srcView.id;
   var srcImg = srcView.image;
   var imgW = srcImg.width, imgH = srcImg.height, numCh = srcImg.numberOfChannels;

   console.writeln("<b>" + TITLE + " v" + VERSION + "</b>");
   console.writeln("來源影像: " + srcId + " (" + imgW + "x" + imgH + ", " + numCh + " ch)");

   var tmpInitial = null, tmpBg1 = null, finalWin = null, finalBgWin = null;
   var trialWin = null, trialBgWin = null; // 迭代中尚未定案的當輪結果視窗

   try {
      // ── 1) 初始 DBE：在複製品上執行，取得殘差資料 ──
      console.writeln("步驟 1/4：在複製品上執行初始 DBE（自動網格 sample）...");

      gDeweightedSamples = 0;
      var sampleRadius = Math.max(10, Math.min(40, Math.round(Math.min(imgW, imgH) * 0.02)));
      var initialTable = buildInitialSampleGrid(srcImg, imgW, imgH, gridPerRow, sampleRadius, numCh);

      var P1 = new DynamicBackgroundExtraction;
      setByExistingName(P1, ["tolerance"], 0.5);
      setByExistingName(P1, ["shadowsRelaxation"], 1.0);
      setByExistingName(P1, ["smoothing", "smoothFactor"], 0.25);
      setByExistingName(P1, ["samplesPerRow"], gridPerRow * gridPerRow);
      assignSamples(P1, initialTable, numCh, imgW, imgH);
      P1.discardModel = false; // 必須保留背景模型，後面殘差分析要用

      // 讀回驗證：確認 DBE 真的收下了這批 data（格式錯誤時會整批被丟掉）
      var readBack = P1.data;
      var readBackLen = (readBack && readBack.length !== undefined) ? readBack.length : 0;
      console.writeln("初始 data table：寫入 " + initialTable.length +
                      " 列，DBE 實際接受 " + readBackLen + " 列");
      if (readBackLen > 0)
         console.writeln("  第一列 = " + JSON.stringify(readBack[0]));
      if (readBackLen < 3)
         throw new Error("DBE 拒絕了初始 data table（接受 " + readBackLen +
                         " 列，需至少 3 列）。嘗試寫入的第一列 = " +
                         JSON.stringify(samplesToData(initialTable, numCh, imgW, imgH)[0]));

      tmpInitial = cloneViewToNewWindow(srcView, srcId + "_AutoPilot_tmp1");
      tmpBg1 = runDBEAndCaptureModel(P1, tmpInitial.mainView);

      var diagParams = extractDBEParams(P1, imgW, imgH, numCh);
      var diagDist = analyzeSampleDistribution(diagParams.samples, imgW, imgH, diagParams.minSampleWeight);
      var residualGrid = computeResidualGrid(srcImg, tmpBg1.mainView.image, residGridN);

      var diag = {
         exporterVersion: VERSION,
         timestamp: (new Date()).toISOString(),
         observingConditions: { bortleScale: bortleScale, filter: filterName, cameraType: cameraType },
         sourceImage: { id: srcId, width: imgW, height: imgH, channels: numCh, stats: [] },
         backgroundModel: { id: tmpBg1.mainView.id, stats: [] },
         residualGrid: residualGrid,
         sampleDistribution: diagDist,
         dbeParams: diagParams
      };
      for (var ch = 0; ch < numCh; ch++) diag.sourceImage.stats.push(channelStats(srcImg, ch));
      for (var ch = 0; ch < tmpBg1.mainView.image.numberOfChannels; ch++)
         diag.backgroundModel.stats.push(channelStats(tmpBg1.mainView.image, ch));

      // 客觀分數：腳本以固定公式計算（AI 只解讀不評分），跨模型/跨輪可比較。
      // 量測對象是初始 sample table 的背景值離散度（星雲訊號不會污染）
      var initialScore = computeObjectiveScore(initialTable, numCh, diag.sourceImage.stats, diagDist);
      initialScore.targetScore = targetScore;
      diag.objectiveScore = initialScore;
      console.writeln("初始設定客觀分數: " + initialScore.score + "/100（目標 " + targetScore + "）");

      var ts = timestampString();
      var diagPath = outputDir + "/dbe_diag_" + ts + ".json";
      writeTextFile(diagPath, JSON.stringify(diag, null, 2));
      console.writeln("已匯出診斷 JSON: " + diagPath);

      // 初始 DBE 的複製品/背景模型只是用來取得診斷資料，關掉以免弄亂工作區
      tmpBg1.forceClose();
      tmpInitial.forceClose();
      tmpInitial = null; tmpBg1 = null;

      // ── 2) 直接呼叫 Claude API 分析（純 JS，不依賴 Python）──
      console.writeln("步驟 2/4：呼叫 AI 分析（" + model + ", effort=" + effort + "）...");
      var reportPath = outputDir + "/dbe_report_" + ts + ".json";

      var report = callClaudeAdvisor(diag, {
         apiKey: apiKey,
         model: model,
         effort: effort,
         extraContext: extraContext,
         timeoutSec: timeoutSec
      });
      writeTextFile(reportPath, JSON.stringify(report, null, 2));

      if (report.raw_response) {
         throw new Error("AI 回應無法解析為結構化 JSON，已中止套用（避免用不明資料跑 DBE）。" +
                         "原始回應已存在 " + reportPath + "，可自行檢視。");
      }
      console.writeln("AI 總評: " + report.summary);

      // ── 3+4) 迭代：套用建議 → 最終 DBE → 驗證量測客觀分數 →
      //          未達目標分數則帶著驗證數據請 AI 再修正、重跑 ──
      var currentReport = report;
      var currentSamples = diagParams.samples;
      var currentParams = { tolerance: 0.5, shadowsRelaxation: 1.0,
                            smoothing: 0.25, samplesPerRow: gridPerRow * gridPerRow };
      var best = null;    // 分數最高的一輪：{ score, scoreObj, win, bgWin, report, actionResult, paramChanges, attempt }
      var history = [];   // 各輪分數 [{ attempt, score }]
      var extraFiles = []; // 迭代產生的額外診斷/報告 JSON

      for (var attempt = 1; attempt <= maxAttempts; attempt++) {
         console.writeln("步驟 3/4：套用 AI 建議（第 " + attempt + "/" + maxAttempts + " 輪）...");
         var actionResult = applySampleActions(currentSamples, currentReport, sampleRadius, numCh, srcImg);

         var P2 = new DynamicBackgroundExtraction;
         setByExistingName(P2, ["tolerance"], currentParams.tolerance);
         setByExistingName(P2, ["shadowsRelaxation"], currentParams.shadowsRelaxation);
         setByExistingName(P2, ["smoothing", "smoothFactor"], currentParams.smoothing);
         setByExistingName(P2, ["samplesPerRow"], currentParams.samplesPerRow);
         var paramChanges = applyParameterSuggestions(P2, currentReport.parameter_suggestions || {});
         assignSamples(P2, actionResult.table, numCh, imgW, imgH);

         // 最終執行設定：以「減法」校正光害梯度、就地取代目標（目標本來就是複製品）、
         // 保留背景模型視窗。normalize=true 會在扣除後把背景中位數加回去，
         // 維持整體亮度水準、避免大量像素變成負值被截為 0（全黑）。
         P2.discardModel = false;
         P2.replaceTarget = true;
         P2.normalize = true;
         var proto = DynamicBackgroundExtraction.prototype;
         if (proto.Subtraction !== undefined)      P2.targetCorrection = proto.Subtraction;
         else if (proto.Subtract !== undefined)    P2.targetCorrection = proto.Subtract;
         else console.warningln("找不到 Subtraction 列舉值，targetCorrection 維持預設（可能不會做扣除）。");

         console.writeln("步驟 4/4：全自動執行最終 DBE（第 " + attempt + " 輪）...");
         if (gDeweightedSamples > 0)
            console.writeln("抗污染機制：累計 " + gDeweightedSamples +
                            " 個取樣點因偏離周邊背景（疑似落在星雲/星暈上）被降權。");
         var suffix = (attempt > 1) ? "_r" + attempt : "";
         trialWin = cloneViewToNewWindow(srcView, srcId + "_DBE_" + ts + suffix);
         trialBgWin = runDBEAndCaptureModel(P2, trialWin.mainView);
         trialBgWin.mainView.id = srcId + "_background_" + ts + suffix;

         // ── 驗證量測：對校正結果重新佈點取樣，算背景離散度客觀分數 ──
         console.writeln("驗證量測：計算第 " + attempt + " 輪結果的客觀分數...");
         var verify = measureSampleDispersion(trialWin.mainView, gridPerRow, sampleRadius, numCh);
         var attemptParams = extractDBEParams(P2, imgW, imgH, numCh);
         var attemptDist = analyzeSampleDistribution(attemptParams.samples, imgW, imgH, attemptParams.minSampleWeight);
         var scoreObj = computeObjectiveScore(verify.table, numCh, verify.stats, attemptDist);
         scoreObj.targetScore = targetScore;
         history.push({ attempt: attempt, score: scoreObj.score });
         console.writeln("第 " + attempt + " 輪客觀分數: " + scoreObj.score + "/100（目標 " + targetScore + "）");

         if (!best || scoreObj.score > best.score) {
            if (best) { // 新結果更好，舊的最佳視窗不再需要
               try { best.win.forceClose(); } catch (e2) {}
               try { best.bgWin.forceClose(); } catch (e2) {}
            }
            best = { score: scoreObj.score, scoreObj: scoreObj, win: trialWin, bgWin: trialBgWin,
                     report: currentReport, actionResult: actionResult,
                     paramChanges: paramChanges, attempt: attempt };
         } else {
            try { trialWin.forceClose(); } catch (e2) {}
            try { trialBgWin.forceClose(); } catch (e2) {}
         }
         trialWin = null; trialBgWin = null;

         if (scoreObj.score >= targetScore) {
            console.writeln("已達目標分數，停止迭代。");
            break;
         }
         if (attempt === maxAttempts) {
            console.warningln("已達最大迭代輪數（" + maxAttempts + "）仍未達 " + targetScore +
                              " 分，保留分數最高的第 " + best.attempt + " 輪結果（" + best.score + " 分）。");
            break;
         }

         // ── 帶驗證數據回饋 AI，取得下一輪修正建議 ──
         // 迭代診斷不再附殘差網格（其大尺度起伏多為星雲訊號，會誤導 AI）；
         // 空間資訊改由 objectiveScore.deviations（背景偏移點位）提供
         var diagIter = {
            exporterVersion: VERSION,
            timestamp: (new Date()).toISOString(),
            observingConditions: diag.observingConditions,
            sourceImage: { id: srcId, width: imgW, height: imgH, channels: numCh, stats: verify.stats },
            sampleDistribution: attemptDist,
            dbeParams: attemptParams,
            objectiveScore: scoreObj,
            iteration: { attempt: attempt, maxAttempts: maxAttempts,
                         targetScore: targetScore, history: history }
         };
         var iterDiagPath = outputDir + "/dbe_diag_" + ts + "_r" + (attempt + 1) + ".json";
         writeTextFile(iterDiagPath, JSON.stringify(diagIter, null, 2));
         extraFiles.push(iterDiagPath);

         console.writeln("未達目標分數，呼叫 AI 修正（第 " + (attempt + 1) + " 輪建議）...");
         var nextReport;
         try {
            nextReport = callClaudeAdvisor(diagIter, {
               apiKey: apiKey, model: model, effort: effort,
               extraContext: extraContext, timeoutSec: timeoutSec
            });
         } catch (eIter) {
            console.warningln("迭代 AI 呼叫失敗（" + eIter + "），停止迭代，保留目前最佳結果。");
            break;
         }
         var iterReportPath = outputDir + "/dbe_report_" + ts + "_r" + (attempt + 1) + ".json";
         writeTextFile(iterReportPath, JSON.stringify(nextReport, null, 2));
         extraFiles.push(iterReportPath);
         if (nextReport.raw_response) {
            console.warningln("迭代 AI 回應無法解析為 JSON，停止迭代，保留目前最佳結果。");
            break;
         }
         console.writeln("AI 修正方向: " + nextReport.summary);

         // 下一輪以「本輪實際使用的 sample 與參數」為基準繼續調整
         currentReport = nextReport;
         currentSamples = attemptParams.samples;
         currentParams = {
            tolerance:         attemptParams.tolerance,
            shadowsRelaxation: attemptParams.shadowsRelaxation,
            smoothing:         attemptParams.smoothingFactor,
            samplesPerRow:     attemptParams.samplesPerRow
         };
      }

      finalWin = best.win;
      finalBgWin = best.bgWin;

      applyAutoSTF(finalWin.mainView);
      applyAutoSTF(finalBgWin.mainView);

      finalWin.show();
      finalBgWin.show();
      finalWin.bringToFront();

      // ── 產生 .txt / .html 調整說明檔 ──
      var txtPath  = outputDir + "/dbe_summary_" + ts + ".txt";
      var htmlPath = outputDir + "/dbe_summary_" + ts + ".html";
      var gridCount = gridPerRow * gridPerRow;
      var reports = buildReports({
         ts: ts, srcId: srcId, imgW: imgW, imgH: imgH, numCh: numCh,
         bortleScale: bortleScale, filterName: filterName,
         cameraLabel: (cameraType === "mono") ? "單色相機（Mono）" : "彩色相機（OSC）",
         model: model, effort: effort,
         gridCount: gridCount,
         edgeCount: initialTable.length - gridCount,
         sampleRadius: sampleRadius,
         residGridN: residGridN,
         residualSummary: summarizeResidualGrid(residualGrid),
         sampleDistribution: diagDist,
         report: best.report,
         actionResult: best.actionResult,
         objective: best.scoreObj,
         initialScore: initialScore.score,
         targetScore: targetScore,
         iterationHistory: history,
         bestAttempt: best.attempt,
         extraFiles: extraFiles,
         finalId: finalWin.mainView.id,
         finalBgId: finalBgWin.mainView.id,
         diagPath: diagPath,
         reportPath: reportPath
      });
      writeTextFile(txtPath, reports.txt);
      writeTextFile(htmlPath, reports.html);
      console.writeln("已寫出調整說明: " + txtPath);
      console.writeln("已寫出調整說明 (HTML): " + htmlPath);

      var histStr = [];
      for (var i = 0; i < history.length; i++)
         histStr.push("第 " + history[i].attempt + " 輪 " + history[i].score + " 分");

      var summary = "";
      summary += "來源影像: " + srcId + "（原視窗未被更動）\n\n";
      summary += "已產生：\n";
      summary += "  " + finalWin.mainView.id + " — 背景校正後影像\n";
      summary += "  " + finalBgWin.mainView.id + " — 背景模型\n\n";
      summary += "客觀分數: " + best.score + "/100（目標 " + targetScore +
                 (best.score >= targetScore ? "，已達標" : "，未達標，保留最佳輪") + "）\n";
      summary += "初始設定 " + initialScore.score + " 分 → " + histStr.join(" → ") +
                 "（採用第 " + best.attempt + " 輪）\n\n";
      summary += "AI 總評: " + best.report.summary + "\n\n";
      summary += "Sample points: 保留 " + best.actionResult.keptCount +
                 "，移除 " + best.actionResult.removedCount +
                 "，新增 " + best.actionResult.addedCount +
                 "，合計 " + best.actionResult.table.length + "\n\n";
      if (best.paramChanges.length > 0)
         summary += "參數調整:\n  " + best.paramChanges.join("\n  ") + "\n\n";
      if (best.actionResult.unparsedNotes.length > 0)
         summary += "以下建議座標格式無法解析，已略過:\n  " +
                    best.actionResult.unparsedNotes.join("\n  ") + "\n\n";
      summary += "調整說明 TXT: " + txtPath + "\n";
      summary += "調整說明 HTML: " + htmlPath + "\n";
      summary += "診斷 JSON: " + diagPath + "\nAI 報告 JSON: " + reportPath;

      console.writeln("<b>" + TITLE + " 完成</b>");
      console.writeln(summary);
      (new MessageBox(summary, TITLE, StdIcon_Information)).execute();

   } catch (e) {
      // 清理任何殘留的暫存視窗，避免留下垃圾視窗
      if (tmpBg1) try { tmpBg1.forceClose(); } catch (e2) {}
      if (tmpInitial) try { tmpInitial.forceClose(); } catch (e2) {}
      if (trialBgWin) try { trialBgWin.forceClose(); } catch (e2) {}
      if (trialWin) try { trialWin.forceClose(); } catch (e2) {}

      console.criticalln("錯誤: " + e);
      (new MessageBox("執行失敗，已中止：\n\n" + e, TITLE, StdIcon_Error)).execute();
   }
}

// 測試 harness 可在 #include 本檔前宣告 DBE_AUTOPILOT_NO_MAIN 以略過啟動
if (typeof DBE_AUTOPILOT_NO_MAIN === "undefined")
   main();
