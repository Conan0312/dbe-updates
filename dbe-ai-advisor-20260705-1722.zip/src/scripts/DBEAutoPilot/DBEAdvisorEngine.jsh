// ============================================================================
// DBEAdvisorEngine.jsh — DBE AI 分析引擎（純 PJSR，不依賴 Python）
//
// 將 bridge/dbe_advisor.py 的功能完整移植為 PJSR：
//   · preprocessDiagnostics(diag)  — 診斷 JSON → 精簡文字摘要（省 token）
//   · callClaudeAdvisor(diag, o)   — 以 NetworkTransfer 直接呼叫 Anthropic
//                                    Messages API，回傳結構化建議 JSON
//   · DBE_SYSTEM_PROMPT            — 領域專用 system prompt（內嵌，
//                                    與 prompts/dbe_system.md 同步維護）
//
// 之所以內嵌 prompt 而不在執行期讀檔：透過 PixInsight Update Repository
// 發佈時，腳本會被安裝到使用者的 PI 安裝目錄，執行期無法可靠取得
// 自身路徑，內嵌字串是最穩的做法。
//
// API 呼叫注意事項：
//   · NetworkTransfer.post() 是同步阻塞呼叫，期間 PI 介面會凍結，
//     屬正常現象（分析通常需要 30~90 秒）
//   · 要求 UTF-8：請求本文先以 encodeURIComponent+unescape 轉成
//     UTF-8 位元組序列再送出，回應以 utf8ToString() 解碼
// ============================================================================

#include <pjsr/DataType.jsh>

#define ADVISOR_API_URL      "https://api.anthropic.com/v1/messages"
#define ADVISOR_API_VERSION  "2023-06-01"
#define ADVISOR_MAX_TOKENS   16000

// ─────────────────────────────────────────────
// System Prompt（與 prompts/dbe_system.md 內容一致）
// ─────────────────────────────────────────────

var DBE_SYSTEM_PROMPT = [
'# DBE Optimization Advisor — System Prompt',
'',
'你是一位專精 PixInsight DynamicBackgroundExtraction (DBE) 的天文影像處理顧問。',
'使用者會提供 DBE 診斷 JSON 資料，你的任務是分析並給出具體、可操作的優化建議。',
'',
'## 你的分析框架',
'',
'### 1. Sample Point 分佈品質',
'- **覆蓋率**：4x4 象限中是否有空白區域？邊角是否有覆蓋？',
'- **均勻性**：uniformityRatio < 0.3 表示嚴重不均勻',
'- **數量**：一般建議 20-60 個 sample points，過少（<15）會導致模型不穩定，過多（>80）可能過度擬合',
'- **邊緣覆蓋**：edgeCoverage 應在 0.3-0.5 之間，太低表示邊角未覆蓋',
'- **權重過低（重要，優先於數量判斷）**：診斷資料的 `sampleDistribution.weakSampleCount` /',
'  `weakQuadrantCounts` / `weakSamples` 記錄了「色版權重低於 minSampleWeight」的 sample。',
'  這些 sample 雖然仍計入該象限的數量，但 DBE 建模時幾乎不採信它們（形同虛設），',
'  通常是因為該點落在星雲、亮星暈或雜訊區。**在建議「增加 sample」之前，一定要先比對',
'  該象限的 sample 數量與權重過低數量**：',
'  - 若某象限 sample 數量不少、但殘差仍嚴重，且該象限出現在 `weakQuadrantCounts` 中',
'    → 真正問題通常不是「數量不足」，而是「現有 sample 落在訊號/雜訊上、被判定低權重」，',
'    應建議「移除/移動這些低權重 sample 到附近乾淨背景」，而非單純叫使用者再加 sample',
'  - 只有在該象限 sample 數量本身就偏少、且沒有明顯的低權重 sample 時，才建議「增加數量」',
'',
'### 2. 殘差網格分析（residualGrid）',
'- **均勻殘差**：理想情況下各格的 mean 應接近 0（或接近統一值），stdDev 應一致',
'- **梯度殘留**：如果某個區域的 mean 明顯偏離整體中位數，表示該區域的背景扣除不足',
'  - 偏高 → 背景扣除不足，**先檢查該區域是否已有 sample、且是否落在',
'    `weakSamples` 清單中**：若有，代表現有 sample 因低權重被忽略，應建議「檢查並移除/',
'    移動落在訊號上的 sample」；只有在該區域本來就沒有 sample 或密度明顯偏低時，',
'    才建議「加 sample 或降低 tolerance」',
'  - 偏低 → 過度扣除（該區可能有 sample 落在暗星雲上）',
'- **角落 vs 中心**：光害漸暈通常在角落最明顯',
'- **條帶狀殘差**：可能暗示 sensor 問題而非 DBE 參數問題',
'',
'### 3. DBE 參數建議（PixInsight 1.9.x）',
'',
'**重要**：DBE 使用 2D surface spline（曲面樣條）建立背景模型，**沒有多項式階數參數**。',
'「modelDegree / Function degree」是 ABE（AutomaticBackgroundExtractor）的參數，',
'DBE 的介面中不存在，**絕對不要建議使用者調整 modelDegree**。',
'模型的形狀完全由 sample points 的位置與 smoothing factor 決定。',
'',
'DBE 實際可調的參數（對應 PixInsight 1.9.3 介面）：',
'',
'- **tolerance**（Model Parameters (1) → Tolerance）：',
'  - 高值（>1.0）→ 更多像素被納入 sample 計算（容錯高但可能含信號）',
'  - 低值（<0.5）→ 更嚴格地排除偏差像素（適合有微弱星雲的區域）',
'  - 一般起點：0.5-1.0',
'- **shadowsRelaxation**（Shadows relaxation）：較高值可避免暗區被過度扣除',
'- **smoothingFactor**（Smoothing factor）：',
'  - 0 → spline 嚴格通過每個 sample（sample 若含雜訊/信號會直接反映在模型上）',
'  - 提高 → 模型更平滑，可抑制局部震盪；預設 0.25 通常是良好起點',
'- **sampleRadius**（Sample Generation → Default sample radius）：sample 取樣半徑，',
'  雜訊高的影像可加大以取得更穩定的背景估計',
'- **samplesPerRow**（Samples per row）：自動生成 sample 的密度，一般 8-15',
'- **minSampleWeight**（Minimum sample weight）：過低會納入受污染的 sample',
'- **修正方式**（Target Image Correction）：',
'  - Subtraction → 加性光害梯度（最常見）',
'  - Division → 乘性漸暈/平場殘留',
'',
'### 4. Bortle 等級與光害漸暈',
'',
'若診斷資料含 `observingConditions.bortleScale`，請將其納入分析：',
'',
'- **Bortle 1-4（暗空/鄉村）**：光害梯度通常輕微且方向單一（例如僅低空一側偏亮），',
'  殘差網格四角與四邊差異若不大，屬正常現象，不需過度加密角落 sample',
'- **Bortle 5-6（郊區）**：四角漸暈開始明顯，建議四個角落（距邊 5-10% 內）',
'  各放 2-3 個 sample，並檢查對角象限是否對稱（例如左上與右下殘差 mean 是否接近）',
'- **Bortle 7-9（城市/市中心）**：光害漸暈通常最嚴重，且可能來自多個方向（多個光源），',
'  四角梯度容易不對稱、甚至出現非線性的複合梯度：',
'  - 建議加大角落與邊緣 sample 密度（每個角落 3-5 個），邊緣中段每側至少 2-3 個',
'  - `tolerance` 可能需要調高（0.75-1.5）以涵蓋較強的光害底噪',
'  - `shadowsRelaxation` 建議提高，避免暗部因高光害背景被過度扣除',
'  - 若殘差網格顯示四角 mean 差異很大（例如某角落明顯高於對角角落），',
'    在 issue 中要明確指出是「不對稱光害梯度」，並建議在殘差較高的角落加測 sample，',
'    而非單純平均分佈',
'  - 評分時，高 Bortle 環境下的四角不對稱殘差應視為較嚴重的問題（提高該項 issue 的 severity）',
'',
'若診斷資料中沒有 `bortleScale`，則不需提及 Bortle，僅依殘差網格數據本身分析梯度。',
'',
'### 5. 光害濾鏡（observingConditions.filter）注意事項',
'',
'若診斷資料含 `observingConditions.filter` 且不是 `"None"`，代表使用者拍攝時加了',
'多波段光害濾鏡（Antlia RGB ULTRA、Askar D1、Askar D2 或兩者疊加）。這類濾鏡的共同特性',
'是「只放行特定窄波段（例如 Ha/OIII 窗口 + 縮窄的 RGB 連續譜窗口）並阻擋常見光害譜線',
'（鈉燈、汞燈、LED 街燈）」，這會影響 DBE 分析的方向：',
'',
'- **各色版通過頻寬不同 → 殘留梯度常常只出現在單一色版**：務必參考殘差網格的',
'  `meanByChannel` / 摘要中的「色版失衡分析」，不要只看跨色版平均的 `mean`。',
'  若某色版（尤其是頻寬最窄的那個，通常是 G）在某區域殘差明顯偏高，',
'  即使整體平均看起來正常，也要在 issue 中指出「Ch{N} 色版殘留梯度」，並提醒',
'  這可能是該濾鏡窄波段內殘留的月光/天光背景，而非單純的地面光害',
'- **入射角偏移（angle-of-incidence shift）**：干涉式濾鏡的通過波段會隨光線入射角',
'  偏移（越靠近影像邊緣/角落，入射角越大，通過波段略往短波長偏移），這會造成一種',
'  「濾鏡本身造成的放射狀漸暈」，疊加在真實光害梯度之上，尤其在快光比（f/4 以下）',
'  系統更明顯。若殘差網格呈現「以影像中心為圓心、越外圍越偏離」的放射狀分佈',
'  （而非單一方向的線性梯度），應在 issue 中指出「可能為濾鏡入射角效應造成的放射狀',
'  漸暈，而非單純光害方向性梯度」，並建議 sample 分佈也要以放射狀（同心圓）方式',
'  加密外圍，而非只加角落',
'- **Askar D1 + D2 疊加使用**：兩片干涉濾鏡疊加會放大上述入射角效應，且整體穿透率',
'  下降、雜訊底較高。若診斷資料的原圖統計顯示 stdDev/MAD 偏高，建議：',
'  - `sampleRadius` 適度加大（例如 15-20），降低雜訊對背景估計的影響',
'  - `tolerance` 可能需要比未疊加濾鏡時略高，因為底噪較高容易讓正常背景像素被誤判為離群值',
'  - 若殘差呈現同心圓/放射狀特徵，優先懷疑濾鏡入射角效應，而非直接判定為光害不對稱',
'- 若同時有 `bortleScale` 又有濾鏡：濾鏡通常會顯著降低光害線本身造成的梯度強度，',
'  但不會消除濾鏡本身的入射角放射狀效應。分析時請把「光害方向性梯度」與',
'  「濾鏡放射狀效應」視為兩種不同成因分開描述，不要混為一談',
'',
'若診斷資料中沒有 `filter` 欄位或其值為 `"None"`，則不需提及濾鏡效應。',
'',
'### 6. 常見陷阱',
'- Sample point 放在星雲/Ha 發射區上 → 會把星雲當背景扣掉',
'- Sample point 放在亮星暈上 → 背景值被高估',
'- smoothingFactor = 0 + sample 落在信號/雜訊上 → 模型出現局部凹陷或凸起',
'- sample 過密（>80）且貼近星雲邊緣 → 大尺度星雲結構被當背景吃掉',
'- 窄帶影像（Ha/OIII/SII）的背景通常很平坦，少量均勻分佈的 sample 即可',
'',
'### 7. 評分標準（score 0-100）',
'',
'診斷資料中的 `sourceImage.width` / `height` 即為影像實際像素尺寸，殘差網格每一格',
'也都附有實際像素邊界（x0, y0, x1, y1）。評分請依下列級距，並在 `summary` 中',
'明確指出目前分數落在哪一級、是否「合格」：',
'',
'| 分數      | 等級          | 說明                                                         |',
'|-----------|---------------|--------------------------------------------------------------|',
'| 85-100    | 優秀          | 可直接執行 DBE，無需再調整即可合格                            |',
'| 70-84     | 合格          | 品質可接受，建議微調但不強制；**70 分為合格底線**             |',
'| 50-69     | 不合格        | 至少有 1 項 high severity 問題，需先處理才建議執行 DBE         |',
'| <50       | 嚴重不合格    | 存在多項 high severity 問題（例如 sample 數為 0、覆蓋率為 0），必須大幅調整後重新匯出診斷再評估 |',
'',
'## 輸出格式',
'',
'請用以下結構回覆（JSON），方便程式解析：',
'',
'```json',
'{',
'  "summary": "一句話總結目前 DBE 的品質，並註明是否達到 70 分合格線",',
'  "score": 0-100,',
'  "issues": [',
'    {',
'      "severity": "high|medium|low",',
'      "category": "sample_distribution|residual_gradient|parameter|coverage",',
'      "description": "具體問題描述（含實際像素座標，格式：(x px, y px) ~ (x px, y px)）",',
'      "suggestion": "具體操作建議（含實際像素座標或參數值）"',
'    }',
'  ],',
'  "parameter_suggestions": {',
'    "tolerance":         { "current": N, "suggested": N, "reason": "..." },',
'    "shadowsRelaxation": { "current": N, "suggested": N, "reason": "..." },',
'    "smoothingFactor":   { "current": N, "suggested": N, "reason": "..." },',
'    "samplesPerRow":     { "current": N, "suggested": N, "reason": "..." }',
'  },',
'  "sample_point_actions": [',
'    {',
'      "action": "add|remove|move",',
'      "region": "格式：(x px, y px) ~ (x px, y px)，例如：(0 px, 3132 px) ~ (1562 px, 4176 px)（左下角）",',
'      "reason": "原因"',
'    }',
'  ],',
'  "next_steps": ["依序列出建議的操作步驟，涉及位置時一律用實際像素座標"]',
'}',
'```',
'',
'## 注意事項',
'- **只建議 DBE 實際存在的參數**（tolerance / shadowsRelaxation / smoothingFactor /',
'  sampleRadius / samplesPerRow / minSampleWeight / 修正方式）；不要提及 modelDegree',
'- **所有座標一律使用實際像素位置，格式固定為 `(x px, y px) ~ (x px, y px)`**',
'  （左上角座標 ~ 右下角座標），例如 `(0 px, 0 px) ~ (1562 px, 1044 px)`；不要只給百分比。',
'  診斷資料的殘差網格已附上每格的 x0/y0/x1/y1 像素邊界，直接引用即可；',
'  若要描述影像邊角、象限等區域，也請換算成該影像實際寬高（width/height）對應的像素範圍',
'- 不要給模糊建議如「調整 sample points」，要說「在 (0 px, 0 px) ~ (1562 px, 1044 px) 範圍內增加 3-4 個 sample points」',
'- 優先處理 severity: high 的問題',
'- 依「評分標準」章節給分，並在 summary 中明確說明是否達到 70 分合格線',
'- 用繁體中文回覆'
].join('\n');

// ─────────────────────────────────────────────
// 診斷資料前處理（移植自 dbe_advisor.py 的 preprocess_diagnostics）
// ─────────────────────────────────────────────

function advisorFmt(x, digits) {
   return (typeof x === "number") ? x.toFixed(digits) : String(x);
}

/**
 * 將完整的診斷 JSON 精簡為 AI 所需的關鍵文字摘要，
 * 避免 token 浪費在冗餘的逐格數據上。
 */
function preprocessDiagnostics(diag) {
   var parts = [];

   // === 拍攝環境 ===
   var obs = diag.observingConditions || {};
   var envLines = [];
   if (obs.bortleScale)
      envLines.push("- Bortle 等級: " + obs.bortleScale +
         "（1=極暗空, 9=市中心；等級越高，光害漸暈通常越強，" +
         "四角/邊緣梯度越明顯，需要更多 sample point 集中在角落與邊緣）");
   if (obs.filter && obs.filter !== "None")
      envLines.push("- 使用濾鏡: " + obs.filter +
         "（使用者自行輸入的濾鏡名稱；請依此濾鏡的實際光學特性" +
         "（頻寬、是否干涉式多波段、是否窄帶）判斷對背景梯度與色版失衡的影響）");
   if (obs.cameraType)
      envLines.push("- 相機類型: " + (obs.cameraType === "mono"
         ? "單色（Mono；此影像若為多通道通常是合成結果，各通道來自不同濾鏡曝光，" +
           "色版失衡可能來自各濾鏡曝光條件差異而非光害）"
         : "彩色（OSC 一體式彩色感光元件；各色版同時曝光，" +
           "色版失衡較可能來自光害譜線或濾鏡通帶差異）"));
   if (envLines.length > 0)
      parts.push("## 拍攝環境\n" + envLines.join("\n"));

   // === 影像基本資訊 ===
   var src = diag.sourceImage || {};
   parts.push("## 影像資訊\n" +
      "- ID: " + (src.id || "N/A") + "\n" +
      "- 尺寸: " + (src.width || "?") + " x " + (src.height || "?") + "\n" +
      "- 通道數: " + (src.channels || "?"));

   // === 原圖統計 ===
   if (src.stats && src.stats.length > 0) {
      var sLines = [];
      for (var i = 0; i < src.stats.length; i++) {
         var s = src.stats[i];
         sLines.push("  Ch" + i + ": mean=" + advisorFmt(s.mean, 6) +
            ", median=" + advisorFmt(s.median, 6) +
            ", stdDev=" + advisorFmt(s.stdDev, 6) +
            ", MAD=" + advisorFmt(s.MAD, 6));
      }
      parts.push("## 原圖統計\n" + sLines.join("\n"));
   }

   // === 背景模型統計 ===
   var bg = diag.backgroundModel || {};
   if (bg.stats && bg.stats.length > 0) {
      var bLines = [];
      for (var i = 0; i < bg.stats.length; i++) {
         var s = bg.stats[i];
         bLines.push("  Ch" + i + ": mean=" + advisorFmt(s.mean, 6) +
            ", median=" + advisorFmt(s.median, 6) +
            ", stdDev=" + advisorFmt(s.stdDev, 6));
      }
      parts.push("## 背景模型統計\n" + bLines.join("\n"));
   }

   // === 殘差網格摘要 ===
   var grid = diag.residualGrid || [];
   if (grid.length > 0) {
      var cells = [];
      for (var r = 0; r < grid.length; r++)
         for (var c = 0; c < grid[r].length; c++)
            cells.push(grid[r][c]);

      var sum = 0, minMean = Infinity, maxMean = -Infinity;
      var minStd = Infinity, maxStd = -Infinity;
      for (var i = 0; i < cells.length; i++) {
         sum += cells[i].mean;
         if (cells[i].mean < minMean) minMean = cells[i].mean;
         if (cells[i].mean > maxMean) maxMean = cells[i].mean;
         if (cells[i].stdDev < minStd) minStd = cells[i].stdDev;
         if (cells[i].stdDev > maxStd) maxStd = cells[i].stdDev;
      }
      var globalMean = sum / cells.length;

      var devs = [];
      for (var i = 0; i < cells.length; i++) {
         var cell = cells[i];
         devs.push({
            row: cell.row, col: cell.col,
            x0: cell.x0, y0: cell.y0, x1: cell.x1, y1: cell.y1,
            mean: cell.mean, dev: Math.abs(cell.mean - globalMean)
         });
      }
      devs.sort(function(a, b) { return b.dev - a.dev; });

      var gLines = [];
      gLines.push("## 殘差網格分析 (" + grid.length + "x" + grid.length + ")");
      gLines.push("- 全域殘差均值: " + advisorFmt(globalMean, 8));
      gLines.push("- 殘差均值範圍: [" + advisorFmt(minMean, 8) + ", " + advisorFmt(maxMean, 8) + "]");
      gLines.push("- 殘差 stdDev 範圍: [" + advisorFmt(minStd, 8) + ", " + advisorFmt(maxStd, 8) + "]");
      gLines.push("");
      gLines.push("### 偏離最大的 5 個區域（可能殘留梯度，座標為實際像素）:");
      for (var i = 0; i < Math.min(5, devs.length); i++) {
         var d = devs[i];
         gLines.push("  [row=" + d.row + ",col=" + d.col + "] " +
            "(" + d.x0 + " px, " + d.y0 + " px) ~ (" + d.x1 + " px, " + d.y1 + " px) " +
            "mean=" + advisorFmt(d.mean, 8) + ", dev=" + advisorFmt(d.dev, 8));
      }
      parts.push(gLines.join("\n"));

      // === 色版失衡分析（多波段濾鏡時特別重要）===
      var chCells = [];
      for (var i = 0; i < cells.length; i++)
         if (cells[i].meanByChannel && cells[i].meanByChannel.length > 1)
            chCells.push(cells[i]);
      if (chCells.length > 0) {
         var imbalance = [];
         for (var i = 0; i < chCells.length; i++) {
            var mbc = chCells[i].meanByChannel;
            var mn = Infinity, mx = -Infinity;
            for (var c = 0; c < mbc.length; c++) {
               if (mbc[c] < mn) mn = mbc[c];
               if (mbc[c] > mx) mx = mbc[c];
            }
            imbalance.push({
               x0: chCells[i].x0, y0: chCells[i].y0,
               x1: chCells[i].x1, y1: chCells[i].y1,
               meanByChannel: mbc, spread: mx - mn
            });
         }
         imbalance.sort(function(a, b) { return b.spread - a.spread; });

         var cLines = ["### 色版失衡最嚴重的 5 個區域（各色版殘差差距最大處）:"];
         for (var i = 0; i < Math.min(5, imbalance.length); i++) {
            var d = imbalance[i];
            var mbcStr = [];
            for (var c = 0; c < d.meanByChannel.length; c++)
               mbcStr.push("Ch" + c + "=" + advisorFmt(d.meanByChannel[c], 8));
            cLines.push("  (" + d.x0 + " px, " + d.y0 + " px) ~ (" +
               d.x1 + " px, " + d.y1 + " px) [" + mbcStr.join(", ") +
               "], 色版間差距=" + advisorFmt(d.spread, 8));
         }
         parts.push(cLines.join("\n"));
      }
   }

   // === DBE 參數 ===
   var dbe = diag.dbeParams;
   if (dbe) {
      parts.push("## DBE 參數（PixInsight 1.9.x）\n" +
         "- tolerance: " + dbe.tolerance + "\n" +
         "- shadowsRelaxation: " + dbe.shadowsRelaxation + "\n" +
         "- smoothingFactor: " + dbe.smoothingFactor + "\n" +
         "- sampleRadius: " + dbe.sampleRadius + "\n" +
         "- samplesPerRow: " + dbe.samplesPerRow + "\n" +
         "- minSampleWeight: " + dbe.minSampleWeight + "\n" +
         "- Sample 總數: " + (dbe.samples ? dbe.samples.length : 0));
   }

   // === Sample 分佈分析 ===
   var dist = diag.sampleDistribution;
   if (dist) {
      parts.push("## Sample Point 分佈分析\n" +
         "- 總數: " + (dist.totalCount || 0) + "\n" +
         "- 均勻性比率: " + advisorFmt(dist.uniformityRatio || 0, 2) +
         "  (1.0=完美均勻, <0.3=嚴重不均)\n" +
         "- 邊緣覆蓋率: " + advisorFmt(dist.edgeCoverage || 0, 2) +
         "  (理想 0.3-0.5)\n" +
         "- 空白象限: " + JSON.stringify(dist.emptyQuadrants || []) + "\n" +
         "- 權重過低（形同虛設）的 sample 數: " + (dist.weakSampleCount || 0) +
         "  (權重門檻 minSampleWeight=" + dist.weightThreshold + ")");

      // 象限明細（含實際像素範圍）
      var imgW = src.width, imgH = src.height;
      var qc = dist.quadrantCounts || {};
      var wq = dist.weakQuadrantCounts || {};
      var qKeys = [];
      for (var key in qc) qKeys.push(key);
      if (qKeys.length > 0 && imgW && imgH) {
         qKeys.sort();
         var qLines = ["### 象限 sample 分佈:"];
         for (var i = 0; i < qKeys.length; i++) {
            var rc = qKeys[i].split("_");
            var r = parseInt(rc[0], 10), c = parseInt(rc[1], 10);
            var qx0 = Math.round(c * imgW / 4), qx1 = Math.round((c + 1) * imgW / 4);
            var qy0 = Math.round(r * imgH / 4), qy1 = Math.round((r + 1) * imgH / 4);
            var weak = wq[qKeys[i]] || 0;
            qLines.push("  [" + r + "," + c + "] (" + qx0 + " px, " + qy0 + " px) ~ (" +
               qx1 + " px, " + qy1 + " px): " + qc[qKeys[i]] + " samples" +
               (weak > 0 ? "，其中 " + weak + " 個權重過低" : ""));
         }
         parts.push(qLines.join("\n"));
      }

      // 權重過低的 sample 明細
      var weakSamples = dist.weakSamples || [];
      if (weakSamples.length > 0) {
         var wLines = ["### 權重過低的 sample（形同虛設，DBE 幾乎忽略它們）:"];
         for (var i = 0; i < Math.min(15, weakSamples.length); i++) {
            var w = weakSamples[i];
            var weights = w.weights || [];
            var wStr = [];
            for (var c = 0; c < weights.length; c++) wStr.push(advisorFmt(weights[c], 2));
            wLines.push("  (" + Math.round(w.center_x || 0) + " px, " +
               Math.round(w.center_y || 0) + " px) 各色版權重=[" + wStr.join(", ") +
               "], 最低=" + advisorFmt(w.minWeight || 0, 2));
         }
         parts.push(wLines.join("\n"));
      }
   }

   return parts.join("\n\n");
}

// ─────────────────────────────────────────────
// HTTP（NetworkTransfer）
// ─────────────────────────────────────────────

/**
 * 收集 NetworkTransfer 的底層錯誤資訊（libcurl 錯誤文字 + HTTP 狀態碼），
 * 供錯誤訊息顯示，方便診斷連線問題（TLS、代理、DNS 等）。
 */
function advisorTransferDetail(T) {
   var parts = [];
   try { if (T.errorInformation) parts.push("curl: " + T.errorInformation); } catch (e) {}
   try {
      if (typeof T.responseCode === "number" && T.responseCode > 0)
         parts.push("HTTP " + T.responseCode);
   } catch (e) {}
   return parts.length > 0 ? parts.join("; ") : "（無底層錯誤資訊）";
}

/**
 * 共同的 transfer 前置設定：URL、SSL、逾時、自訂標頭。
 * @param {Number} timeoutSec  傳輸逾時秒數。實測 setConnectionTimeout 蓋的是
 *   「整個傳輸過程」而非僅連線建立——AI 生成需 30~90 秒，POST 必須給足
 *   （設 30 秒會在生成途中被切斷，且錯誤被誤標為 SSL/TLS connection timeout）
 */
function advisorSetupTransfer(T, url, headers, timeoutSec) {
   T.setURL(url);
   // 明確啟用 SSL（部分 PI 版本 https 需要顯式呼叫 setSSL）
   try { T.setSSL(); } catch (e) {}
   try {
      if (typeof T.setConnectionTimeout === "function")
         T.setConnectionTimeout(timeoutSec || 30);
   } catch (e) {}
   // 自訂標頭：必須用「換行分隔的單一字串」——陣列形式不會丟例外
   // 但標頭不會被送出（實測 API 回報 x-api-key header is required）
   try { T.setCustomHTTPHeaders(headers.join("\n")); }
   catch (e1) {
      try { T.setCustomHTTPHeaders(headers); }
      catch (e2) {
         throw new Error("無法設定 HTTP 標頭（setCustomHTTPHeaders 失敗）: " + e2);
      }
   }
}

/**
 * 以 NetworkTransfer 送出 HTTPS POST（JSON），回傳 { ok, text, detail }。
 * 同步阻塞；期間 PI 介面凍結屬正常現象。
 */
function advisorHttpPost(url, headers, bodyText, timeoutSec) {
   var T = new NetworkTransfer;
   advisorSetupTransfer(T, url, headers, timeoutSec || 180);

   var response = new ByteArray;
   T.onDownloadDataAvailable = function(data) {
      response.add(data);
      return true;
   };

   // 本文轉成 UTF-8 位元組序列再送出（含中文的 system prompt 必須如此）
   var utf8Body = unescape(encodeURIComponent(bodyText));
   var ok = T.post(utf8Body);

   var text = (typeof response.utf8ToString === "function")
      ? response.utf8ToString() : response.toString();
   return { ok: ok, text: text, detail: advisorTransferDetail(T) };
}

/**
 * 從 Anthropic /v1/models 取得可用模型清單（GET）。
 * 離線或金鑰無效時丟例外，呼叫端自行 fallback 到預設模型。
 * @returns {Array} 模型 id 字串陣列（依 API 回傳順序，最新在前）
 */
function fetchAvailableModels(apiKey) {
   var T = new NetworkTransfer;
   var headers = [
      "x-api-key: " + apiKey,
      "anthropic-version: " + ADVISOR_API_VERSION
   ];
   advisorSetupTransfer(T, "https://api.anthropic.com/v1/models?limit=100", headers, 15);

   var response = new ByteArray;
   T.onDownloadDataAvailable = function(data) { response.add(data); return true; };
   var ok = T.download();

   var text = (typeof response.utf8ToString === "function")
      ? response.utf8ToString() : response.toString();
   if (!ok && !text)
      throw new Error("無法連線至 Anthropic API。底層錯誤: " + advisorTransferDetail(T));

   var parsed = JSON.parse(text);
   if (parsed.type === "error")
      throw new Error(parsed.error ? parsed.error.message : text.substring(0, 200));

   var ids = [];
   var data = parsed.data || [];
   for (var i = 0; i < data.length; i++)
      if (data[i].id) ids.push(data[i].id);
   if (ids.length === 0)
      throw new Error("模型清單為空");
   return ids;
}

// ─────────────────────────────────────────────
// 主要入口：呼叫 Claude API 取得 DBE 建議
// ─────────────────────────────────────────────

/**
 * @param {Object} diag  DBEAutoPilot 組出的診斷 JSON
 * @param {Object} o     { apiKey, model, effort, extraContext, timeoutSec }
 * @returns {Object} 結構化建議 JSON；無法解析時回傳 { raw_response: "..." }
 * @throws  API 錯誤（金鑰無效、超額、網路失敗等）會直接丟例外
 */
function callClaudeAdvisor(diag, o) {
   if (!o.apiKey)
      throw new Error("未提供 Anthropic API Key。");

   var summaryText = preprocessDiagnostics(diag);
   var userText = "以下是 DBE 診斷資料，請分析並給出優化建議：\n\n" + summaryText;
   if (o.extraContext)
      userText += "\n\n## 使用者附加說明\n" + o.extraContext;
   userText += "\n\n請以指定的 JSON 格式回覆。";

   var requestBody = JSON.stringify({
      model: o.model,
      max_tokens: ADVISOR_MAX_TOKENS,
      thinking: { type: "adaptive" },
      output_config: { effort: o.effort },
      system: DBE_SYSTEM_PROMPT,
      messages: [{ role: "user", content: userText }]
   });

   var headers = [
      "Content-Type: application/json",
      "x-api-key: " + o.apiKey,
      "anthropic-version: " + ADVISOR_API_VERSION
   ];

   console.writeln("呼叫 " + o.model + " (effort=" + o.effort +
                   ", adaptive thinking)... 分析通常需要 30~90 秒，期間介面會凍結。");
   console.flush();

   var res = advisorHttpPost(ADVISOR_API_URL, headers, requestBody, o.timeoutSec || 180);
   if (!res.ok && !res.text)
      throw new Error("API 呼叫失敗（無回應）。底層錯誤: " + res.detail +
                      "。可能原因：TLS 憑證驗證失敗、公司/防毒軟體代理攔截、DNS 問題。");

   var parsed;
   try {
      parsed = JSON.parse(res.text);
   } catch (e) {
      throw new Error("API 回應不是有效 JSON：" + res.text.substring(0, 500));
   }

   // API 層級錯誤（金鑰無效、超額、模型名錯誤等）
   if (parsed.type === "error")
      throw new Error("API 錯誤 [" + (parsed.error ? parsed.error.type : "?") + "]: " +
                      (parsed.error ? parsed.error.message : res.text.substring(0, 300)));

   // 取出所有 text block（跳過 thinking block）
   var rawText = "";
   var content = parsed.content || [];
   for (var i = 0; i < content.length; i++)
      if (content[i].type === "text")
         rawText += content[i].text;

   if (parsed.usage)
      console.writeln("Token 用量: input=" + parsed.usage.input_tokens +
                      ", output=" + parsed.usage.output_tokens);

   // 從回應擷取 JSON（可能被 ```json ... ``` 包裹）
   var jsonText = rawText;
   var m = jsonText.indexOf("```json");
   if (m >= 0) {
      jsonText = jsonText.substring(m + 7);
      var end = jsonText.indexOf("```");
      if (end >= 0) jsonText = jsonText.substring(0, end);
   } else {
      m = jsonText.indexOf("```");
      if (m >= 0) {
         jsonText = jsonText.substring(m + 3);
         var end2 = jsonText.indexOf("```");
         if (end2 >= 0) jsonText = jsonText.substring(0, end2);
      }
   }

   try {
      return JSON.parse(jsonText.replace(/^\s+|\s+$/g, ""));
   } catch (e) {
      return { raw_response: rawText };
   }
}
